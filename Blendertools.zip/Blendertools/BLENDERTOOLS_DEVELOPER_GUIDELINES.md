# Blendertools — Developer Reference

> Version: 3.0.0
> Blender: 5.0+
> Author: m

---

## What is Blendertools

A modular, context-aware N-panel addon for Blender. A single wrapper (`__init__.py`) automatically discovers, loads, and renders tools from a `tools/` subfolder. Each tool is a self-contained `.py` file. The wrapper handles all panel registration, stack management, context filtering, and hot-reload — tool authors only write tool logic.

---

## Folder Architecture

```
blendertools/                          ← addon root (zip this for installation)
│
├── __init__.py                        ← wrapper — never edit for tool work
├── BLENDERTOOLS_DEV.md                ← this file
│
├── tools/                             ← drop tool files here
│   ├── blendertools_active_camera_hud.py
│   ├── blendertools_camera_from_view.py
│   ├── blendertools_quick_aspect_camera.py
│   ├── blendertools_compositor_quicknodes.py  ← mock/test tool
│   └── blendertools_shader_quickmat.py        ← mock/test tool
│
└── icons/
    └── Logo.png                       ← custom header logo (optional)
```

**File naming rules:**
- Every tool file **must** be prefixed `blendertools_` — this prevents import collisions with Python stdlib or other installed packages when `importlib.import_module()` runs
- Files starting with `_` are ignored by the scanner — safe to use for private helpers
- The `tools/` folder is hot-reloadable — drop a file in and press the Reload button (↺) in the panel header; no Blender restart needed

---

## Tool File Contract

Every tool file must provide exactly three things:

### 1. `TOOL_INFO` dict (required)

```python
TOOL_INFO = {
    # --- Required ---
    "id":      "blendertools_my_tool",  # unique snake_case identifier
    "name":    "My Tool",              # shown in dashboard cards, stack headers, and the Add Tool menu
    "context": "VIEW_3D",              # which editor this tool lives in — omit to default to VIEW_3D

    # --- Optional ---
    "context_subtype": "ShaderNodeTree",  # narrows within shared space types (see Context Reference)
    "description": "One line shown on the dashboard card.",
    "help":        "Longer text shown in the inline help toggle.\n\nSupports \\n paragraphs.",
}
```

### 2. `draw_tool(context, layout)` function (required)

Called by the wrapper to render the tool's UI inside its accordion box. Only called when the current editor matches the tool's declared context — never called in the wrong editor.

```python
def draw_tool(context, layout):
    layout.operator("my.operator", text="Do Thing")
```

### 3. `register()` and `unregister()` functions (required)

Standard Blender registration. Called by the wrapper on load and on every Reload. `unregister()` must be safe to call even if registration partially failed — use try/except per class.

```python
def register():
    for cls in classes:
        bpy.utils.register_class(cls)

def unregister():
    for cls in reversed(classes):
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass
```

---

## Context Reference

### `"context"` → `bl_space_type`

| Value                | Editor                  | Panel registered? |
|----------------------|-------------------------|-------------------|
| `"VIEW_3D"`          | 3D Viewport             | Yes               |
| `"NODE_EDITOR"`      | Any node editor         | Yes (shared)      |
| `"IMAGE_EDITOR"`     | Image Editor            | Yes               |
| `"SEQUENCE_EDITOR"`  | Video Sequencer         | Yes               |
| `"CLIP_EDITOR"`      | Movie Clip Editor       | Yes               |
| `"DOPESHEET_EDITOR"` | Dopesheet / Action      | Yes               |
| `"GRAPH_EDITOR"`     | Graph Editor            | Yes               |
| `"NLA_EDITOR"`       | NLA Editor              | Yes               |
| `"TEXT_EDITOR"`      | Text Editor             | Yes               |

> `PROPERTIES` and `OUTLINER` are intentionally excluded — they use a different layout system incompatible with the N-panel UI region.

### `"context_subtype"` → narrows within shared space types

Required when you want a tool to appear in only one variant of an editor that hosts multiple modes under the same `bl_space_type`.

**NODE_EDITOR subtypes** (resolved from `space_data.tree_type`):

| Value                   | Editor              |
|-------------------------|---------------------|
| `"ShaderNodeTree"`      | Shader Editor       |
| `"CompositorNodeTree"`  | Compositor          |
| `"GeometryNodeTree"`    | Geometry Nodes      |
| `"TextureNodeTree"`     | Texture Nodes       |

**DOPESHEET_EDITOR subtypes** (resolved from `space_data.ui_mode`):

| Value         | Editor           |
|---------------|------------------|
| `"DOPESHEET"` | Dopesheet        |
| `"ACTION"`    | Action Editor    |
| `"SHAPEKEY"`  | Shape Key Editor |
| `"GPENCIL"`   | Grease Pencil    |
| `"MASK"`      | Mask             |

**Omit `context_subtype`** if the tool should appear in all variants of a shared space. A `NODE_EDITOR` tool without a subtype appears in Shader Editor, Compositor, and Geometry Nodes simultaneously.

---

## How the Wrapper Behaves

### Panel registration
- Nine concrete panel classes are always registered at startup — one per supported editor
- Each panel has a `poll()` classmethod that calls `_has_tools_for_context(context)` at draw time
- `_has_tools_for_context()` checks whether any loaded tool matches **both** the current `space_type` AND `context_subtype` — space alone is too coarse for shared editors like `NODE_EDITOR`
- `_SUPPORTED_SPACES` is the canonical set of space types with registered panel classes — tool validation checks against this at load time
- If no loaded tool matches exactly, `poll()` returns `False` and the panel is invisible — e.g. Geometry Nodes panel stays hidden when only Compositor and Shader tools exist
- Panels **never** use dynamic `type()` class generation — Blender's RNA system requires proper subclasses defined at module level; `type()` appears to register but `draw` methods silently fail to fire

### Home dashboard (HOME page)
- Shows only tools whose `context` (and `context_subtype` if declared) matches the current editor
- Each card shows name, description, and an Open button that adds the tool to the shared stack

### Add Tool menu (TOOLS page)
- A custom `bpy.types.Menu` (not an `EnumProperty` — Blender has no API to disable individual enum items)
- All tools are listed, grouped by context label with separators
- **Group ordering:** the current editor's group appears first; all others follow alphabetically
- **Within each group:** active (matching) tools appear before grayed ones
- **Dimming:** foreign groups have `row.active = False` applied to both the header label and each tool row — two levels of visual separation (active vs. dimmed vs. disabled)
- Grayed tools are non-clickable (`row.enabled = False`) but visible for reference

### Tools stack (TOOLS page)
- One shared stack stored as a `CollectionProperty` on `bpy.types.Scene` — persists across editors
- Each editor's panel **only renders stack items that match its own context** — foreign tools are invisible here, not grayed
- They appear in their own editor's panel when you switch to it
- `draw_tool()` is only called when the tool's context matches — never called in the wrong editor
- The X remove button is always available regardless of context

### Inline help
- INFO (ℹ) button on each stack item toggles an inline help box below the header
- Content: `TOOL_INFO["help"]`, falling back to `TOOL_INFO["description"]`
- Rendered with word-wrap at ~32 chars to fit the N-panel width

### Tool loading & validation
- After each module is imported, `_validate_tool_info()` runs before `register()` is called
- Checks: `TOOL_INFO` exists, required keys (`id`, `name`) present, `context` is a known `_SUPPORTED_SPACES` value, `context_subtype` is valid for its space type, `draw_tool()` / `register()` / `unregister()` all exist
- Fatal errors (missing `TOOL_INFO`, unrecognised `context`) skip the tool entirely with a clear console message — the tool never enters `_LOADED` or `_SCANNED`
- Non-fatal issues (missing `description`, bad subtype) print warnings but still load the tool
- All messages are prefixed `[Blendertools] VALIDATION WARNING — <filename>` for easy console filtering

### Reload (↺ button)
- Calls `_unload_all_tools()`: unregisters all tool modules, purges `sys.modules` entries
- Re-scans `tools/`, re-imports, validates, and re-registers each module
- Panel visibility updates automatically on next redraw via `poll()`
- Reports tool count in Blender's Info bar

---

## Critical Implementation Notes for Developers

These are hard-won findings from development — do not repeat these mistakes:

1. **Never use `type()` to create panel classes.** Blender's RNA system accepts `type()`-generated panels at registration but `draw` and `draw_header` methods silently fail to fire at draw time. Always use proper `class MyPanel(bpy.types.Panel):` subclasses defined at module level.

2. **`EnumProperty` items cannot be individually disabled.** There is no per-item flag. If you need a mixed enabled/disabled list, use `bpy.types.Menu` with `row.enabled = False` per entry.

3. **`box.enabled = False` does not prevent `draw_tool()` from executing.** It only dims the layout visually. Always gate `draw_tool()` calls with an explicit `if in_ctx:` check.

4. **`draw_wrapped()` must receive `context` to derive wrap width correctly.** The fixed `wrap_width=32` breaks at non-default UI scales and HiDPI. Always call `draw_wrapped(layout, text, context=context)` inside draw functions. The function calculates width from `context.region.width / (6.0 * ui_scale)` with a fallback to 32 when context is unavailable.

5. **`is_cur_grp` must match both space AND subtype** when grouping menu items. Matching space alone is too coarse — in the Shader Editor, `is_cur_grp = (space == "NODE_EDITOR")` would also be True for Compositor tools, putting them in bucket 0 and sorting them before Shader Editor alphabetically. Always use the three-way logic: space match → subtype declared? match subtype : match only if current has no subtype.

6. **`poll()` must use full context matching, not space-type alone.** `_has_tools_for_space(space_type)` causes the panel to appear in Geometry Nodes whenever any NODE_EDITOR tool exists (Shader, Compositor). Always use `_has_tools_for_context(context)` which delegates to `_tool_matches_context()` and checks both space and subtype.

7. **Tool filenames must use the `blendertools_` prefix.** Without it, `importlib.import_module()` may shadow Python stdlib modules. The prefix guarantees a unique namespace.

8. **Always purge `sys.modules` before re-importing on Reload.** Without this, Python returns the cached stale module and changes to the file are ignored.

9. **Check operator collisions before `register()`, not after.** `_check_operator_collisions()` runs pre-registration so the warning names the incoming tool as the offender. Check both `bpy.ops` (Blender + external addons) and `_REGISTERED_IDNAMES` (other tools in the same toolset).

---

## Minimal Tool Template

Copy-paste this to start a new tool:

```python
# tools/blendertools_my_tool.py

TOOL_INFO = {
    "id":          "blendertools_my_tool",
    "name":        "My Tool",
    "context":     "VIEW_3D",
    "description": "Short description shown on the dashboard card.",
    "help":        "Longer explanation shown in the inline help box.\n\nSupports paragraphs.",
}

import bpy


class MY_OT_do_thing(bpy.types.Operator):
    bl_idname      = "my.do_thing"
    bl_label       = "Do Thing"
    bl_description = "Does the thing"
    bl_options     = {'REGISTER', 'UNDO'}

    def execute(self, context):
        self.report({'INFO'}, "Thing done!")
        return {'FINISHED'}


def draw_tool(context, layout):
    layout.operator("my.do_thing", text="Do Thing", icon='CHECKMARK')


classes = [MY_OT_do_thing]


def register():
    for cls in classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(classes):
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass
```

---

## Existing Tools

### `blendertools_active_camera_hud`
- **Context:** `VIEW_3D`
- **What it does:** Draws a live HUD overlay in the 3D viewport showing the active render camera (respects timeline markers) and the current viewport camera.
- **Controls:** Enable/disable toggle, corner position (TL/TR/BL/BR), font size, ignore overlays toggle.
- **Properties on:** `bpy.types.WindowManager`

### `blendertools_camera_from_view`
- **Context:** `VIEW_3D`
- **What it does:** Creates a camera exactly matching the current viewport angle, enables Lock Camera to View, auto-names it (`Cam_001`, `Cam_002`…), places it in a `Cameras` collection.
- **Operator:** `view3d.camera_from_view_lock`

### `blendertools_quick_aspect_camera`
- **Context:** `VIEW_3D`
- **What it does:** One-click resolution presets (1080×1080, 1920×1080, etc.) with optional scene duplication, auto-output path management with token-based filename templates, and overwrite policy.
- **Properties on:** `bpy.types.Scene` (prefixed `qac21_`)

### `blendertools_compositor_quicknodes` *(mock/test)*
- **Context:** `NODE_EDITOR` / `context_subtype: "CompositorNodeTree"`
- **What it does:** Mock tool for testing Compositor panel context. Buttons report to Info bar only, no actual node tree modification.

### `blendertools_shader_quickmat` *(mock/test)*
- **Context:** `NODE_EDITOR` / `context_subtype: "ShaderNodeTree"`
- **What it does:** Mock tool for testing Shader Editor panel context. Buttons report to Info bar only, no actual node tree modification.

---

## Wrapper Version History

| Version | Key changes |
|---------|-------------|
| 2.1 | Initial modular stack system |
| 2.2 | Dynamic tool loading from `tools/` folder |
| 2.3 | Tool loading fix — `sys.path.insert` + `sys.modules` purge; wordwrap fix; trash button rework |
| 2.4 | Tool files renamed to `blendertools_` prefix convention |
| 2.5 | Inline help toggle per tool; bright/dim nav buttons (`sub.active`); reload operator (↺); full tooltips on all operators and properties |
| 2.6 | Context-aware system introduced — `TOOL_INFO["context"]` + `["context_subtype"]`; attempted dynamic panel factory via `type()` — silently broken |
| 2.7 | Factory rewrite attempt with module-level draw functions; still used `type()` — draw methods still failed to fire |
| 2.8 | **Root fix** — `type()` abandoned entirely; nine concrete `bpy.types.Panel` subclasses at module level; `poll()` classmethod controls visibility per editor; all editors working |
| 2.9 | `EnumProperty` dropdown replaced with `bpy.types.Menu` for per-item `enabled`/`active` control; stack filtered per-context (foreign tools invisible, not grayed); Add Tool menu groups tools by context with current-editor group always first; `is_cur_grp` fixed to match both space AND subtype — space-only matching caused wrong group prioritisation in shared space types like `NODE_EDITOR` |
| 2.9.1 | `poll()` fixed to use `_has_tools_for_context(context)` instead of `_has_tools_for_space(space_type)` — panel now hidden in Geometry Nodes / any editor variant with no matching tools, not just editors with no tools at all |
| 3.0.0 | `_validate_tool_info()` schema validation; `_SUPPORTED_SPACES` canonical set; `draw_wrapped()` dynamic width from `context.region.width` / `ui_scale` |
| 3.1.0 | `_check_operator_collisions()` pre-registration collision detection against `bpy.ops` and `_REGISTERED_IDNAMES`; `_register_idnames()` tracks loaded idnames; cleared on reload; nine panel classes documented as exhaustive for all N-panel-capable Blender editors |
| 3.2.0 | Per-editor page state — `bt_current_page` Scene EnumProperty replaced with one `StringProperty` per space type on `WindowManager`; `_get_page()` / `_set_page()` helpers; each editor remembers its own HOME/TOOLS/HELP state independently |
| 3.3.0 | `draw_wrapped()` upgraded from fixed `6.0px/char` to `blf.dimensions(0, 'W')[0]` exact glyph sampling — correct at any font, UI scale, and HiDPI; `import blf` added |


---

## Tool Module — Known Failure Modes & Edge Cases

This section is for tool authors. Every item here is something that will either silently misbehave, crash the draw loop, or break the entire addon if not handled correctly.

---

### FATAL — Tool is skipped entirely, never appears

**Missing `TOOL_INFO` dict**
The wrapper's `_validate_tool_info()` returns `False` and the tool is skipped. No panel entry, no stack entry. Check the Blender console for `[Blendertools] VALIDATION WARNING`.

**`"context"` value not in `_SUPPORTED_SPACES`**
e.g. `"context": "SHADER_EDITOR"` (wrong), `"context": "VIEW3D"` (missing underscore). The tool is skipped and a console warning names the bad value and lists all valid options. Always copy-paste context strings from the Context Reference table — never type them from memory.

**`register()` raises an exception**
If your `register()` crashes (duplicate `bl_idname`, bad property definition, etc.), the tool is caught by the outer `try/except` in `scan_and_load_tools()`, skipped from `_LOADED` and `_SCANNED`, and a full traceback is printed. The rest of the addon loads normally. Check the console.

---

### SILENT FAILURES — Tool loads but behaves wrongly with no error

**`"context"` key omitted entirely**
Defaults silently to `"VIEW_3D"`. Intentional for VIEW_3D tools, but if you're writing a Compositor tool and forget the key, it will appear in the 3D View panel instead and never show in the Compositor. Validation prints a warning but the tool still loads.

**`"context_subtype"` typo**
e.g. `"CompositorNodeTree"` mistyped as `"CompositorNodenode"`. Validation warns but the tool still loads — it will appear in all NODE_EDITOR variants instead of just the Compositor, because the subtype match fails and the tool falls back to space-only matching. Visually it looks like it's working but it's appearing in the wrong editors.

**`"context_subtype"` set on a space that doesn't use subtypes**
e.g. setting `"context_subtype": "something"` on a `"VIEW_3D"` tool. Validation warns, value is ignored, tool loads normally in VIEW_3D. Confusing but not breaking.

**Operator `bl_idname` collision with another loaded tool**
The collision warning fires but both tools still load. Whichever file sorts alphabetically first registers its operator — the second one's `register()` silently overwrites it. At runtime one tool's button will call the other tool's operator. No crash, completely wrong behaviour. Always prefix `bl_idname` with a unique tool-specific string e.g. `"mytool.do_thing"` not `"utils.do_thing"`.

**Operator `bl_idname` collision with a Blender built-in**
Same outcome — your operator silently overwrites a Blender built-in for the session. This can break unrelated Blender functionality. Always use a unique category prefix in your `bl_idname`. Never use categories like `"object"`, `"mesh"`, `"render"` etc.

**Properties registered on `bpy.types.Scene` or `bpy.types.WindowManager` without unique prefixes**
If two tools both register `bpy.types.Scene.my_prop`, the second overwrites the first silently. Always prefix your properties with a short unique tool identifier e.g. `cam_hud_enable` not `enable`.

**`draw_tool()` references a property that failed to register**
If `register()` partially fails — say, three of five properties registered before an exception — `draw_tool()` will crash on the missing property every draw cycle. The wrapper's per-tool `try/except` catches this and shows a `Draw error:` label in the accordion, but the tool is non-functional. Fix `register()` first.

---

### DRAW LOOP FAILURES — Crash or error shown in the accordion

**`draw_tool()` raises any exception**
Caught by the wrapper's individual `try/except`. A red `Draw error: <message>` label appears inside the tool's accordion box. Other tools in the stack are unaffected. Fix the exception — the error message is shown directly in the panel.

**`draw_tool()` calls `context.space_data` attributes that don't exist in the current editor**
Won't happen in normal use because the wrapper gates `draw_tool()` with `if in_ctx` — it is only called when the tool's declared context matches the current editor. If you bypass this by calling operators that invoke `draw_tool()` manually, all bets are off.

**`draw_tool()` calls `bpy.ops` operators with `EXEC_DEFAULT` that require a specific context**
Some Blender operators fail silently or raise `RuntimeError: Operator bpy.ops.X.poll() failed` when called from a panel draw. Never call `bpy.ops` inside `draw_tool()` directly — only use `layout.operator()` to let the user trigger them.

**Infinite recursion in `draw_tool()`**
If `draw_tool()` triggers a property update that forces a redraw that calls `draw_tool()` again. Blender will freeze or crash. Never write to scene/wm properties inside `draw_tool()` — only read them.

---

### RELOAD EDGE CASES

**Tool file renamed between reloads**
The old name stays in the stack's `CollectionProperty` data (stored on `bpy.types.Scene`). On reload the old name is no longer in `_LOADED`, so the wrapper's stack draw silently skips it (`if not mod: continue`). The orphaned entry stays in the stack data invisibly. It is harmless but wastes a slot. Clear the stack after renaming tool files.

**Tool file deleted while its tool is in the stack**
Same as above — orphaned stack entry, silently skipped in draw. Clear the stack after removing tools.

**`unregister()` raises an exception during reload**
Caught by `_unload_all_tools()` with `traceback.print_exc()`. The module is still evicted from `_LOADED` and `sys.modules`. However if `unregister()` failed partway through, some classes or properties may remain registered from the previous load. On the next `register()` call Blender will raise `RuntimeError: already registered` for those classes. Fix `unregister()` to be safe — always wrap each `bpy.utils.unregister_class()` call in its own `try/except`.

**Two tool files that define classes with the same Python class name**
e.g. both define `class MY_OT_operator`. Python module isolation means these don't conflict at import time — each module has its own namespace. But if both call `bpy.utils.register_class(MY_OT_operator)` and the `bl_idname` strings are also the same, collision detection will catch it. If the class names match but `bl_idname` strings differ, no collision — both register fine.

**Tool imports a third-party Python package not bundled with Blender**
The import will raise `ModuleNotFoundError` inside `importlib.import_module()`, caught by the outer `try/except`. Tool is skipped. Bundle all dependencies inside the tool file or inside the `tools/` folder as a private module (prefix filename with `_` to prevent the scanner from treating it as a tool).

---

### CONTEXT EDGE CASES

**Tool declares `"context": "NODE_EDITOR"` without a `context_subtype`**
The tool appears in ALL node editor variants — Shader Editor, Compositor, Geometry Nodes, Texture Nodes. This is intentional if you want a tool that works everywhere in the node editor. If you only want one variant, always set `context_subtype`.

**Tool added to stack from one editor, then that editor's tool is expected in another editor's stack view**
By design the stack only renders tools matching the current editor. Tools from other editors are invisible in the current panel — they exist in the stack data and appear in their own editor's panel. This is intentional, not a bug.

**`draw_tool()` uses `context.space_data.tree_type` without checking it exists**
`context.space_data` can be `None` in rare Blender states (e.g. during startup, modal operators, background renders). Always guard with `if not context.space_data: return`.

---

### PROPERTY LIFECYCLE EDGE CASES

**Properties registered on `bpy.types.Scene` persist in `.blend` files**
Scene properties are saved with the file. If you change a property's type between tool versions (e.g. `IntProperty` → `FloatProperty` with the same name), Blender may silently fail to load the saved value or coerce it in unexpected ways. Version your property names if the type changes.

**Properties registered on `bpy.types.WindowManager` do NOT persist**
WindowManager properties reset every Blender session. Do not use them for anything the user expects to survive a restart. Use `Scene` properties for persistent settings, `WindowManager` for session-only UI state.

**Calling `delattr(bpy.types.WindowManager, prop)` on a prop that was never registered**
Raises `AttributeError`. Always guard with `if hasattr(bpy.types.WindowManager, prop)` before deleting. The wrapper does this — your tool's `unregister()` should too.

---

## Backlog

Known improvements deferred by 80/20 analysis — implement when toolset grows:

### `"priority"` key in `TOOL_INFO`

Collision detection warns correctly but load order is non-deterministic (alphabetical). An optional `"priority": 0` integer in `TOOL_INFO`, with `_SCANNED` sorted by priority before the import loop, would make load order explicit. Non-urgent at current toolset size. Revisit at ~15+ tools or when shared operator patterns emerge.
