# blendertools/__init__.py
#
# v3.0
# - TOOL_INFO schema validation with clear console warnings.
# - _SUPPORTED_SPACES canonical set.
# - draw_wrapped() dynamic width from context.region.width / ui_scale.
#
# v3.1
# - Operator collision detection.
# - _REGISTERED_IDNAMES cleared on _unload_all_tools().
#
# v3.2
# - Per-editor page state via WindowManager StringProperties.
#
# v3.3
# - draw_wrapped() calibrated 5.5px/char constant replacing broken blf approach.
#
# v3.4
# - Per-editor page state extended to include subtype in the property key.
#   Previously NODE_EDITOR used one shared wm property for Compositor,
#   Shader Editor, and Geometry Nodes — switching between them reset page
#   state. Now each (space, subtype) pair gets its own key, e.g.
#   bt_page_node_editor_shadernodetree vs bt_page_node_editor_compositornodetree.
#   DOPESHEET_EDITOR subtypes are handled the same way.
# -----------------------------------------------------------------------------

bl_info = {
    "name": "Blendertools v1.0",
    "author": "m",
    "version": (1, 0, 1),
    "blender": (5, 0, 0),
    "location": "N-Panel > Blendertools",
    "description": "Context-aware dynamic tool stack — panels visible only in editors that have tools.",
    "category": "3D View",
}

import bpy
import os
import sys
import importlib
import traceback
import textwrap
import bpy.utils.previews

ADDON_DIR = os.path.dirname(__file__)
TOOLS_DIR = os.path.join(ADDON_DIR, "tools")
ICONS_DIR = os.path.join(ADDON_DIR, "icons")

_LOADED            = {}   # mod_name → module
_SCANNED           = []   # ordered list of successfully loaded mod_names
_REGISTERED_IDNAMES = {}  # bl_idname → mod_name that registered it

preview_collections = {}

_SPACE_LABELS = {
    "VIEW_3D":           "3D View",
    "IMAGE_EDITOR":      "Image Editor",
    "NODE_EDITOR":       "Node Editor",
    "SEQUENCE_EDITOR":   "Video Sequencer",
    "CLIP_EDITOR":       "Movie Clip Editor",
    "DOPESHEET_EDITOR":  "Dopesheet",
    "GRAPH_EDITOR":      "Graph Editor",
    "NLA_EDITOR":        "NLA Editor",
    "TEXT_EDITOR":       "Text Editor",
}

_SUBTYPE_LABELS = {
    "ShaderNodeTree":     "Shader Editor",
    "CompositorNodeTree": "Compositor",
    "GeometryNodeTree":   "Geometry Nodes",
    "TextureNodeTree":    "Texture Nodes",
}


# Canonical set of space types that have a registered panel class.
# Used by validation to warn tool authors immediately when they target
# an editor the wrapper doesn't support, instead of silently disappearing.
_SUPPORTED_SPACES = {
    "VIEW_3D",
    "NODE_EDITOR",
    "IMAGE_EDITOR",
    "SEQUENCE_EDITOR",
    "CLIP_EDITOR",
    "DOPESHEET_EDITOR",
    "GRAPH_EDITOR",
    "NLA_EDITOR",
    "TEXT_EDITOR",
}

# Valid NODE_EDITOR subtypes — used in validation
_VALID_NODE_SUBTYPES = {
    "ShaderNodeTree",
    "CompositorNodeTree",
    "GeometryNodeTree",
    "TextureNodeTree",
}

# Valid DOPESHEET_EDITOR subtypes — used in validation
_VALID_DOPESHEET_SUBTYPES = {
    "DOPESHEET",
    "ACTION",
    "SHAPEKEY",
    "GPENCIL",
    "MASK",
}


# =============================================================================
# Context helpers
# =============================================================================

def _tool_space(mod):
    return getattr(mod, "TOOL_INFO", {}).get("context", "VIEW_3D")

def _tool_subtype(mod):
    return getattr(mod, "TOOL_INFO", {}).get("context_subtype", None)

def _current_space(context):
    return context.area.type if (context and context.area) else "VIEW_3D"

def _current_subtype(context):
    if not (context and context.space_data):
        return None
    space = _current_space(context)
    if space == "NODE_EDITOR":
        return getattr(context.space_data, "tree_type", None)
    if space == "DOPESHEET_EDITOR":
        return getattr(context.space_data, "ui_mode", None)
    return None

def _tool_matches_context(mod, context):
    if _tool_space(mod) != _current_space(context):
        return False
    sub = _tool_subtype(mod)
    if sub is not None and sub != _current_subtype(context):
        return False
    return True

def _has_tools_for_context(context):
    """
    True if at least one loaded tool exactly matches the current editor context
    (space type AND subtype). This is what poll() must use — space-type alone
    is too coarse for shared editors like NODE_EDITOR which hosts Shader,
    Compositor, and Geometry Nodes. Without subtype matching the panel would
    appear in Geometry Nodes even when only Shader/Compositor tools exist.
    """
    return any(_tool_matches_context(mod, context) for mod in _LOADED.values())

def _tool_context_label(mod):
    """Human-readable context label for a tool, used in menu separators."""
    sub = _tool_subtype(mod)
    if sub:
        return _SUBTYPE_LABELS.get(sub, sub)
    return _SPACE_LABELS.get(_tool_space(mod), _tool_space(mod))


# =============================================================================
# Per-editor page state helpers
# Each supported space type gets its own StringProperty on WindowManager so
# the 3D View, Compositor, Shader Editor etc. each remember their own
# HOME / TOOLS / HELP state independently.
# =============================================================================

_VALID_PAGES = {'HOME', 'TOOLS', 'HELP'}

def _page_prop(space_type, subtype=None):
    """
    Return the wm attribute name for a given (space_type, subtype) pair.
    Subtypes are included so Compositor, Shader Editor, and Geometry Nodes
    each get independent page state despite all sharing NODE_EDITOR.
    Same applies to DOPESHEET_EDITOR variants.
    """
    base = f"bt_page_{space_type.lower()}"
    if subtype:
        return f"{base}_{subtype.lower()}"
    return base

def _context_page_prop(context):
    """Derive the correct wm property name for the current editor."""
    return _page_prop(_current_space(context), _current_subtype(context))

def _get_page(context):
    """Return the current page string for the active editor+subtype."""
    prop = _context_page_prop(context)
    # Property may not exist yet if subtype wasn't registered at startup
    # (e.g. a node tree type loaded after Blender started) — fall back to HOME
    return getattr(context.window_manager, prop, 'HOME')

def _set_page(context, value):
    """Set the page for the active editor+subtype."""
    if value not in _VALID_PAGES:
        return
    prop = _context_page_prop(context)
    try:
        setattr(context.window_manager, prop, value)
    except Exception:
        # Property not registered for this subtype — register it on the fly
        try:
            setattr(bpy.types.WindowManager, prop,
                    bpy.props.StringProperty(default='HOME'))
            setattr(context.window_manager, prop, value)
        except Exception:
            pass


# =============================================================================
# Tool loading
# =============================================================================

def ensure_dirs():
    os.makedirs(TOOLS_DIR, exist_ok=True)
    os.makedirs(ICONS_DIR, exist_ok=True)

def _unload_all_tools():
    for mod_name, mod in list(_LOADED.items()):
        if hasattr(mod, "unregister"):
            try:
                mod.unregister()
            except Exception:
                traceback.print_exc()
        sys.modules.pop(mod_name, None)
    _LOADED.clear()
    _SCANNED.clear()
    _REGISTERED_IDNAMES.clear()

def _validate_tool_info(mod_name, mod):
    """
    Validate TOOL_INFO schema on a freshly loaded module.
    Prints clear console warnings for every problem found.
    Returns True if the tool is safe to use, False if it has a fatal error
    (missing TOOL_INFO entirely, or an unsupported/unrecognised context).
    """
    prefix = f"[Blendertools] VALIDATION WARNING — {mod_name}"

    if not hasattr(mod, "TOOL_INFO"):
        print(f"{prefix}: missing TOOL_INFO dict. Tool will not appear anywhere.")
        return False

    info = mod.TOOL_INFO

    # Required keys
    for key in ("id", "name"):
        if key not in info:
            print(f"{prefix}: TOOL_INFO missing required key '{key}'.")

    # context value
    ctx = info.get("context", None)
    if ctx is None:
        print(f"{prefix}: TOOL_INFO has no 'context' key — defaulting to 'VIEW_3D'.")
    elif ctx not in _SUPPORTED_SPACES:
        print(
            f"{prefix}: TOOL_INFO 'context' = '{ctx}' is not a supported space type.\n"
            f"  Supported values: {sorted(_SUPPORTED_SPACES)}\n"
            f"  Tool will not appear in any panel. Fix the context value."
        )
        return False

    # context_subtype — only validate when context is set to a shared space type
    sub = info.get("context_subtype", None)
    if sub is not None:
        if ctx == "NODE_EDITOR" and sub not in _VALID_NODE_SUBTYPES:
            print(
                f"{prefix}: TOOL_INFO 'context_subtype' = '{sub}' is not valid for NODE_EDITOR.\n"
                f"  Valid values: {sorted(_VALID_NODE_SUBTYPES)}"
            )
        elif ctx == "DOPESHEET_EDITOR" and sub not in _VALID_DOPESHEET_SUBTYPES:
            print(
                f"{prefix}: TOOL_INFO 'context_subtype' = '{sub}' is not valid for DOPESHEET_EDITOR.\n"
                f"  Valid values: {sorted(_VALID_DOPESHEET_SUBTYPES)}"
            )
        elif ctx not in ("NODE_EDITOR", "DOPESHEET_EDITOR"):
            print(
                f"{prefix}: TOOL_INFO 'context_subtype' = '{sub}' is set but "
                f"'{ctx}' does not use subtypes — value will be ignored."
            )

    # draw_tool presence
    if not hasattr(mod, "draw_tool"):
        print(f"{prefix}: missing draw_tool(context, layout) function.")

    # register / unregister presence
    for fn in ("register", "unregister"):
        if not hasattr(mod, fn):
            print(f"{prefix}: missing {fn}() function.")

    return True


def _check_operator_collisions(mod_name, mod):
    """
    Inspect every class in the module for bl_idname before register() is called.
    Checks two collision surfaces:

    1. bpy.ops — already registered by Blender itself or another installed addon.
       Detected via hasattr(bpy.ops.<category>, '<name>') using the idname parts.

    2. _REGISTERED_IDNAMES — already registered by a previously loaded Blendertools
       tool in this session. Detected via direct dict lookup.

    Collisions are non-fatal: the tool still loads so the developer can see and
    fix the conflict. All warnings are prefixed consistently for console filtering.
    """
    prefix   = f"[Blendertools] COLLISION WARNING — {mod_name}"
    collided = False

    for attr_name in dir(mod):
        cls = getattr(mod, attr_name, None)
        if not isinstance(cls, type):
            continue
        idname = getattr(cls, "bl_idname", None)
        if not idname or "." not in idname:
            continue  # not a Blender operator class

        # Check against other Blendertools tools loaded this session
        if idname in _REGISTERED_IDNAMES:
            owner = _REGISTERED_IDNAMES[idname]
            print(
                f"{prefix}: operator '{idname}' (class {cls.__name__}) "
                f"conflicts with the same idname already registered by '{owner}'.\n"
                f"  One will silently overwrite the other. Rename one bl_idname."
            )
            collided = True

        # Check against bpy.ops (Blender built-ins + other installed addons)
        try:
            category, name = idname.split(".", 1)
            cat_ops = getattr(bpy.ops, category, None)
            if cat_ops and hasattr(cat_ops, name):
                print(
                    f"{prefix}: operator '{idname}' (class {cls.__name__}) "
                    f"conflicts with an already-registered operator in bpy.ops.{category}.\n"
                    f"  This will silently overwrite the existing operator. Rename bl_idname."
                )
                collided = True
        except Exception:
            pass  # malformed idname — schema validation will catch it separately

    if collided:
        print(
            f"[Blendertools] {mod_name} has operator collision(s) — "
            f"tool loaded but conflicts must be resolved."
        )

    return collided   # caller uses this for logging only; tool still loads


def _register_idnames(mod_name, mod):
    """Record all bl_idnames from mod into _REGISTERED_IDNAMES after registration."""
    for attr_name in dir(mod):
        cls = getattr(mod, attr_name, None)
        if not isinstance(cls, type):
            continue
        idname = getattr(cls, "bl_idname", None)
        if idname and "." in idname:
            _REGISTERED_IDNAMES[idname] = mod_name


def scan_and_load_tools():
    ensure_dirs()
    if TOOLS_DIR not in sys.path:
        sys.path.insert(0, TOOLS_DIR)
    for fn in sorted(os.listdir(TOOLS_DIR)):
        if not fn.endswith(".py") or fn.startswith("_"):
            continue
        mod_name = os.path.splitext(fn)[0]
        try:
            sys.modules.pop(mod_name, None)
            mod = importlib.import_module(mod_name)

            # Validate schema — fatal errors skip the tool
            if not _validate_tool_info(mod_name, mod):
                print(f"[Blendertools] SKIPPED (schema error): {mod_name}")
                continue

            # Check operator collisions before register() fires
            _check_operator_collisions(mod_name, mod)

            if hasattr(mod, "register"):
                mod.register()

            # Record idnames now that registration succeeded
            _register_idnames(mod_name, mod)

            _LOADED[mod_name] = mod
            _SCANNED.append(mod_name)
            print(f"[Blendertools] Loaded OK: {mod_name}")
        except Exception as e:
            traceback.print_exc()
            print(f"[Blendertools] FAILED: {mod_name}: {e}")


# =============================================================================
# Word-wrap helper
# =============================================================================

def draw_wrapped(layout, text, context=None, wrap_width=None):
    """
    Render word-wrapped text as label rows in layout.
    wrap_width derived from context.region.width / (5.5 * ui_scale) —
    calibrated for Blender's Inter UI font. Falls back to 32 chars when
    called outside a draw context.
    """
    if wrap_width is None:
        try:
            region_w = context.region.width if context and context.region else 0
            if region_w > 0:
                # 5.5px per character is the calibrated constant for Blender's
                # Inter UI font at ui_scale=1.0. blf.dimensions() was tried but
                # it requires an active OpenGL context — returns 0 in layout draw,
                # causing the fallback to 7.0px which wraps too early.
                ui_scale   = bpy.context.preferences.system.ui_scale
                char_w     = 5.5 * ui_scale
                # ~20px total padding inside an N-panel box
                wrap_width = max(20, int((region_w - 20) / char_w))
            else:
                wrap_width = 32
        except Exception:
            wrap_width = 32

    for para in text.split('\n'):
        if not para.strip():
            layout.separator(factor=0.3)
            continue
        for line in textwrap.wrap(para, width=wrap_width):
            layout.label(text=line)


# =============================================================================
# Custom tool-picker Menu
# Replaces EnumProperty dropdown. Uses a proper bpy.types.Menu so individual
# rows can be disabled (grayed, non-clickable) via row.enabled = False.
# All tools are listed; only tools matching the current editor are enabled.
# =============================================================================

class BT_MT_tool_picker(bpy.types.Menu):
    bl_idname = "BT_MT_tool_picker"
    bl_label  = "Add Tool to Stack"

    def draw(self, context):
        layout = self.layout

        if not _SCANNED:
            layout.label(text="No tools loaded.", icon='INFO')
            return

        # Sort: exact current-context group first (bucket 0), rest alphabetically (bucket 1).
        # is_cur_grp matches BOTH space AND subtype — space alone is too coarse
        # for shared space types (NODE_EDITOR hosts Shader, Compositor, Geo Nodes).
        # Without subtype matching, all NODE_EDITOR tools land in bucket 0 in any
        # node editor, and alphabetical label sort puts Compositor before Shader
        # Editor regardless of which one is actually active.
        cur_space   = _current_space(context)
        cur_subtype = _current_subtype(context)
        entries     = []

        for t in _SCANNED:
            mod = _LOADED.get(t)
            if not mod:
                continue
            info     = getattr(mod, "TOOL_INFO", {})
            name     = info.get("name", t)
            in_ctx   = _tool_matches_context(mod, context)
            ctx_lbl  = _tool_context_label(mod)
            tool_sub = _tool_subtype(mod)

            # A tool is in the current group when:
            # - its space matches AND
            # - if it declares a subtype: that subtype matches cur_subtype
            # - if it has no subtype: the current editor also has no subtype
            if _tool_space(mod) != cur_space:
                is_cur_grp = False
            elif tool_sub is not None:
                is_cur_grp = (tool_sub == cur_subtype)
            else:
                is_cur_grp = (cur_subtype is None)

            sort_key = (0 if is_cur_grp else 1, ctx_lbl, not in_ctx)
            entries.append((sort_key, ctx_lbl, t, name, in_ctx, is_cur_grp))

        entries.sort(key=lambda e: e[0])

        last_ctx = None
        for sort_key, ctx_lbl, t, name, in_ctx, is_cur_grp in entries:
            if ctx_lbl != last_ctx:
                if last_ctx is not None:
                    layout.separator()
                hdr        = layout.row()
                hdr.active = is_cur_grp
                hdr.label(text=ctx_lbl + ":", icon='PLUGIN')
                last_ctx   = ctx_lbl

            row         = layout.row()
            row.active  = is_cur_grp
            row.enabled = in_ctx
            op          = row.operator("bt.add_to_stack", text=name)
            op.tool_name = t


# =============================================================================
# Shared panel draw functions
# =============================================================================

def _shared_draw_header(panel, context):
    sc     = context.scene
    layout = panel.layout
    pcoll  = preview_collections.get("main")
    row    = layout.row(align=True)

    sub = row.row(align=True)
    sub.active = (_get_page(context) == 'HOME')
    if pcoll and "logo" in pcoll:
        sub.operator("bt.set_page", text="",
                     icon_value=pcoll["logo"].icon_id).page = 'HOME'
    else:
        sub.operator("bt.set_page", text="", icon='HOME').page = 'HOME'

    sub = row.row(align=True)
    sub.active = (_get_page(context) == 'TOOLS')
    sub.operator("bt.set_page", text="", icon='MODIFIER').page = 'TOOLS'

    sub = row.row(align=True)
    sub.active = (_get_page(context) == 'HELP')
    sub.operator("bt.set_page", text="", icon='HELP').page = 'HELP'

    row.separator()
    row.operator("bt.reload_tools", text="", icon='FILE_REFRESH')


def _shared_draw(panel, context):
    sc     = context.scene
    layout = panel.layout

    try:
        # -----------------------------------------------------------------
        # HOME — only tools matching the current editor
        # -----------------------------------------------------------------
        if _get_page(context) == 'HOME':
            layout.label(text="Available Tools:", icon='ASSET_MANAGER')
            layout.separator()

            ctx_tools = [
                t for t in _SCANNED
                if t in _LOADED and _tool_matches_context(_LOADED[t], context)
            ]

            if not ctx_tools:
                layout.label(text="No tools for this editor.", icon='INFO')
                return

            for t in ctx_tools:
                mod  = _LOADED[t]
                info = getattr(mod, "TOOL_INFO", {})
                name = info.get("name", t)
                desc = str(info.get("description", "")) or "No description available."

                box    = layout.box()
                col    = box.column(align=True)
                # Tool name + optional version on same row
                tool_ver = info.get("version", "")
                hrow     = col.row(align=True)
                hrow.label(text=name, icon='PLUGIN')
                if tool_ver:
                    vrow        = hrow.row()
                    vrow.active = False
                    vrow.alignment = 'RIGHT'
                    vrow.label(text=f"v{tool_ver}")
                dc         = col.column()
                dc.scale_y = 0.85
                draw_wrapped(dc, desc, context=context)
                col.separator()
                col.operator("bt.add_to_stack",
                             text="Open " + name,
                             icon='ADD').tool_name = t

        # -----------------------------------------------------------------
        # TOOLS STACK
        # Only tools matching the current editor are shown.
        # Tools from other editors are skipped entirely — they exist in the
        # stack data but are invisible here; they appear in their own editor.
        # -----------------------------------------------------------------
        elif _get_page(context) == 'TOOLS':
            stack_len = len(sc.bt_tool_stack)

            # Custom menu button replaces EnumProperty dropdown
            row           = layout.row(align=True)
            row.menu("BT_MT_tool_picker", text="+ Add Tool", icon='ADD')
            clear         = row.row(align=True)
            clear.enabled = (stack_len > 0)
            clear.operator("bt.clear_stack", text="", icon='TRASH')

            layout.separator()

            # Filter stack to current context only
            ctx_items = [
                (i, item) for i, item in enumerate(sc.bt_tool_stack)
                if item.name in _LOADED
                and _tool_matches_context(_LOADED[item.name], context)
            ]

            if not ctx_items:
                if stack_len == 0:
                    layout.label(text="Stack is empty. Add a tool above!", icon='INFO')
                else:
                    layout.label(text="No tools for this editor in the stack.", icon='INFO')
                return

            for i, item in ctx_items:
                mod  = _LOADED[item.name]
                info = getattr(mod, "TOOL_INFO", {})
                tool_name = info.get("name", item.name)
                help_text = info.get("help", info.get("description", "No help available."))

                box    = layout.box()
                header = box.row(align=True)

                acc_icon = 'TRIA_DOWN' if item.is_open else 'TRIA_RIGHT'
                header.prop(item, "is_open", text=tool_name,
                            icon=acc_icon, emboss=False)

                info_row        = header.row(align=True)
                info_row.active = item.show_help
                info_row.prop(item, "show_help", text="",
                              icon='INFO', emboss=True, toggle=True)

                rm_row         = header.row(align=True)
                rm_row.enabled = True
                rm_row.operator("bt.remove_from_stack",
                                text="", icon='X').index = i

                if item.show_help:
                    hbox         = box.box()
                    hcol         = hbox.column(align=True)
                    hcol.scale_y = 0.82
                    tool_ver = info.get("version", "")
                    if tool_ver:
                        vrow        = hcol.row()
                        vrow.active = False
                        vrow.label(text=f"Version: {tool_ver}")
                        hcol.separator(factor=0.3)
                    draw_wrapped(hcol, help_text, context=context)

                if item.is_open and hasattr(mod, 'draw_tool'):
                    inner = box.column()
                    inner.separator(factor=0.5)
                    try:
                        mod.draw_tool(context, inner)
                    except Exception as e:
                        inner.label(text=f"Draw error: {e}", icon='ERROR')
                        traceback.print_exc()

        # -----------------------------------------------------------------
        # HELP
        # -----------------------------------------------------------------
        elif _get_page(context) == 'HELP':
            box = layout.box()
            v   = bl_info["version"]
            box.label(text=f"Blendertools v{v[0]}.{v[1]}.{v[2]}", icon='INFO')
            box.separator()
            draw_wrapped(box.column(), (
                "Welcome to Blendertools!\n\n"
                "HOME — shows tools available for the current editor only.\n\n"
                "TOOLS — your stack, filtered to the current editor. "
                "Tools added in other editors appear there, not here. "
                "Use the '+ Add Tool' menu to add tools — "
                "out-of-context tools are listed but grayed out.\n\n"
                "RELOAD — rescan the tools folder, no restart needed.\n\n"
                "INFO button reveals inline help per tool.\n\n"
                "X removes a tool. Trash clears the full stack."
            ), context=context)

    except Exception as e:
        layout.label(text=f"UI Error: {e}", icon='ERROR')
        traceback.print_exc()


# =============================================================================
# Concrete panel classes — poll() hides panel when no tools exist for editor
# =============================================================================

class BT_PT_view3d(bpy.types.Panel):
    bl_label = "Blendertools"; bl_idname = "BT_PT_view3d"
    bl_space_type = 'VIEW_3D'; bl_region_type = 'UI'; bl_category = "Blendertools"
    @classmethod
    def poll(cls, context): return _has_tools_for_context(context)
    def draw_header(self, context): _shared_draw_header(self, context)
    def draw(self, context): _shared_draw(self, context)

class BT_PT_node(bpy.types.Panel):
    bl_label = "Blendertools"; bl_idname = "BT_PT_node"
    bl_space_type = 'NODE_EDITOR'; bl_region_type = 'UI'; bl_category = "Blendertools"
    @classmethod
    def poll(cls, context): return _has_tools_for_context(context)
    def draw_header(self, context): _shared_draw_header(self, context)
    def draw(self, context): _shared_draw(self, context)

class BT_PT_image(bpy.types.Panel):
    bl_label = "Blendertools"; bl_idname = "BT_PT_image"
    bl_space_type = 'IMAGE_EDITOR'; bl_region_type = 'UI'; bl_category = "Blendertools"
    @classmethod
    def poll(cls, context): return _has_tools_for_context(context)
    def draw_header(self, context): _shared_draw_header(self, context)
    def draw(self, context): _shared_draw(self, context)

class BT_PT_sequencer(bpy.types.Panel):
    bl_label = "Blendertools"; bl_idname = "BT_PT_sequencer"
    bl_space_type = 'SEQUENCE_EDITOR'; bl_region_type = 'UI'; bl_category = "Blendertools"
    @classmethod
    def poll(cls, context): return _has_tools_for_context(context)
    def draw_header(self, context): _shared_draw_header(self, context)
    def draw(self, context): _shared_draw(self, context)

class BT_PT_clip(bpy.types.Panel):
    bl_label = "Blendertools"; bl_idname = "BT_PT_clip"
    bl_space_type = 'CLIP_EDITOR'; bl_region_type = 'UI'; bl_category = "Blendertools"
    @classmethod
    def poll(cls, context): return _has_tools_for_context(context)
    def draw_header(self, context): _shared_draw_header(self, context)
    def draw(self, context): _shared_draw(self, context)

class BT_PT_dopesheet(bpy.types.Panel):
    bl_label = "Blendertools"; bl_idname = "BT_PT_dopesheet"
    bl_space_type = 'DOPESHEET_EDITOR'; bl_region_type = 'UI'; bl_category = "Blendertools"
    @classmethod
    def poll(cls, context): return _has_tools_for_context(context)
    def draw_header(self, context): _shared_draw_header(self, context)
    def draw(self, context): _shared_draw(self, context)

class BT_PT_graph(bpy.types.Panel):
    bl_label = "Blendertools"; bl_idname = "BT_PT_graph"
    bl_space_type = 'GRAPH_EDITOR'; bl_region_type = 'UI'; bl_category = "Blendertools"
    @classmethod
    def poll(cls, context): return _has_tools_for_context(context)
    def draw_header(self, context): _shared_draw_header(self, context)
    def draw(self, context): _shared_draw(self, context)

class BT_PT_nla(bpy.types.Panel):
    bl_label = "Blendertools"; bl_idname = "BT_PT_nla"
    bl_space_type = 'NLA_EDITOR'; bl_region_type = 'UI'; bl_category = "Blendertools"
    @classmethod
    def poll(cls, context): return _has_tools_for_context(context)
    def draw_header(self, context): _shared_draw_header(self, context)
    def draw(self, context): _shared_draw(self, context)

class BT_PT_text(bpy.types.Panel):
    bl_label = "Blendertools"; bl_idname = "BT_PT_text"
    bl_space_type = 'TEXT_EDITOR'; bl_region_type = 'UI'; bl_category = "Blendertools"
    @classmethod
    def poll(cls, context): return _has_tools_for_context(context)
    def draw_header(self, context): _shared_draw_header(self, context)
    def draw(self, context): _shared_draw(self, context)


# =============================================================================
# Data models
# =============================================================================

class BlendertoolsStackItem(bpy.types.PropertyGroup):
    name: bpy.props.StringProperty()
    is_open: bpy.props.BoolProperty(default=True)
    show_help: bpy.props.BoolProperty(
        name="Show Help",
        description="Toggle inline help text for this tool",
        default=False,
    )


# =============================================================================
# Operators
# =============================================================================

class BT_OT_add_to_stack(bpy.types.Operator):
    bl_idname      = "bt.add_to_stack"
    bl_label       = "Open Tool"
    bl_description = "Add this tool to the stack and switch to the Tools page"
    tool_name: bpy.props.StringProperty()

    def execute(self, context):
        t = self.tool_name
        if not t:
            return {'CANCELLED'}
        sc = context.scene
        if not any(item.name == t for item in sc.bt_tool_stack):
            new_item         = sc.bt_tool_stack.add()
            new_item.name    = t
            new_item.is_open = True
        _set_page(context, 'TOOLS')
        return {'FINISHED'}


class BT_OT_remove_from_stack(bpy.types.Operator):
    bl_idname      = "bt.remove_from_stack"
    bl_label       = "Remove Tool"
    bl_description = "Remove this tool from the stack"
    index: bpy.props.IntProperty()

    def execute(self, context):
        context.scene.bt_tool_stack.remove(self.index)
        return {'FINISHED'}


class BT_OT_clear_stack(bpy.types.Operator):
    bl_idname      = "bt.clear_stack"
    bl_label       = "Clear Tool Stack"
    bl_description = "Remove all tools from the stack"

    def execute(self, context):
        context.scene.bt_tool_stack.clear()
        return {'FINISHED'}


class BT_OT_set_page(bpy.types.Operator):
    bl_idname      = "bt.set_page"
    bl_label       = "Set Page"
    bl_description = "Switch to this panel page"
    page: bpy.props.StringProperty()

    def execute(self, context):
        _set_page(context, self.page)
        return {'FINISHED'}


class BT_OT_reload_tools(bpy.types.Operator):
    bl_idname      = "bt.reload_tools"
    bl_label       = "Reload Tools"
    bl_description = "Re-scan the tools folder and reload all modules — no restart needed"

    def execute(self, context):
        _unload_all_tools()
        scan_and_load_tools()
        self.report({'INFO'}, f"Reloaded — {len(_SCANNED)} tool(s) found.")
        return {'FINISHED'}


# =============================================================================
# Registration
# =============================================================================

CLASSES = (
    BlendertoolsStackItem,
    BT_MT_tool_picker,
    BT_OT_add_to_stack,
    BT_OT_remove_from_stack,
    BT_OT_clear_stack,
    BT_OT_set_page,
    BT_OT_reload_tools,
    BT_PT_view3d,
    BT_PT_node,
    BT_PT_image,
    BT_PT_sequencer,
    BT_PT_clip,
    BT_PT_dopesheet,
    BT_PT_graph,
    BT_PT_nla,
    BT_PT_text,
)


def register():
    pcoll     = bpy.utils.previews.new()
    logo_path = os.path.join(ICONS_DIR, "Logo.png")
    if os.path.exists(logo_path):
        pcoll.load("logo", logo_path, 'IMAGE')
    preview_collections["main"] = pcoll

    for c in CLASSES:
        bpy.utils.register_class(c)

    # Per-editor page state — one StringProperty per (space, subtype) pair
    # on WindowManager (session-only, no .blend persistence needed)
    _page_keys = set()
    # Base space keys
    for _space in _SUPPORTED_SPACES:
        _page_keys.add(_page_prop(_space))
    # Subtype keys for shared space types
    for _sub in _VALID_NODE_SUBTYPES:
        _page_keys.add(_page_prop('NODE_EDITOR', _sub))
    for _sub in _VALID_DOPESHEET_SUBTYPES:
        _page_keys.add(_page_prop('DOPESHEET_EDITOR', _sub))
    for _key in _page_keys:
        setattr(
            bpy.types.WindowManager,
            _key,
            bpy.props.StringProperty(default='HOME'),
        )
    bpy.types.Scene.bt_tool_stack = bpy.props.CollectionProperty(
        type=BlendertoolsStackItem,
    )

    scan_and_load_tools()


def unregister():
    _unload_all_tools()

    for pcoll in preview_collections.values():
        bpy.utils.previews.remove(pcoll)
    preview_collections.clear()

    for c in reversed(CLASSES):
        bpy.utils.unregister_class(c)

    # Remove per-editor page props from WindowManager
    _page_keys = set()
    for _space in _SUPPORTED_SPACES:
        _page_keys.add(_page_prop(_space))
    for _sub in _VALID_NODE_SUBTYPES:
        _page_keys.add(_page_prop('NODE_EDITOR', _sub))
    for _sub in _VALID_DOPESHEET_SUBTYPES:
        _page_keys.add(_page_prop('DOPESHEET_EDITOR', _sub))
    for _key in _page_keys:
        if hasattr(bpy.types.WindowManager, _key):
            try:
                delattr(bpy.types.WindowManager, _key)
            except Exception:
                pass

    # Remove stack prop from Scene
    if hasattr(bpy.types.Scene, 'bt_tool_stack'):
        try:
            delattr(bpy.types.Scene, 'bt_tool_stack')
        except Exception:
            pass


if __name__ == "__main__":
    register()