# tools/blendertools_camera_from_view.py

TOOL_INFO = {
    "id":          "blendertools_camera_from_view",
    "version":     "1.0",
    "name":        "Camera From View + Lock",
    "context":     "VIEW_3D",
    "description": "Instantly creates a camera matching your current viewport angle, locks it to view, auto-names it, and places it in a Cameras collection.",
    "help": (
        "Captures your current 3D viewport angle and instantly creates a camera "
        "matching that exact view.\n\n"
        "Lock Camera to View is automatically engaged so you can immediately "
        "refine the framing by orbiting.\n\n"
        "The new camera is auto-named (Cam_001, Cam_002 …) and linked into a "
        "dedicated 'Cameras' collection to keep your outliner tidy."
    ),
}

import bpy


def get_next_camera_name():
    i = 1
    while True:
        name = f"Cam_{i:03d}"
        if name not in bpy.data.cameras:
            return name
        i += 1


def get_or_create_camera_collection():
    col_name = "Cameras"
    if col_name in bpy.data.collections:
        return bpy.data.collections[col_name]
    new_col = bpy.data.collections.new(col_name)
    bpy.context.scene.collection.children.link(new_col)
    return new_col


class VIEW3D_OT_camera_from_view_lock(bpy.types.Operator):
    bl_idname      = "view3d.camera_from_view_lock"
    bl_label       = "Create Camera from View + Lock"
    bl_description = (
        "Create a new camera at the current viewport position and angle, "
        "set it as the active render camera, enable Lock Camera to View, "
        "and move it into the Cameras collection"
    )
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        area  = None
        space = None

        for a in context.screen.areas:
            if a.type == 'VIEW_3D':
                area  = a
                space = a.spaces.active
                break

        if not area or not space:
            self.report({'ERROR'}, "No 3D View found!")
            return {'CANCELLED'}

        view_matrix = space.region_3d.view_matrix.inverted()

        cam_name = get_next_camera_name()
        cam_data = bpy.data.cameras.new(name=cam_name)
        cam_obj  = bpy.data.objects.new(cam_name, cam_data)
        cam_obj.matrix_world = view_matrix

        cam_col = get_or_create_camera_collection()
        cam_col.objects.link(cam_obj)

        for col in bpy.data.collections:
            if col != cam_col and cam_obj.name in col.objects:
                col.objects.unlink(cam_obj)

        context.scene.camera = cam_obj
        context.view_layer.objects.active = cam_obj
        cam_obj.select_set(True)

        space.region_3d.view_perspective = 'CAMERA'
        space.lock_camera = True

        self.report({'INFO'}, f"Camera {cam_obj.name} created and locked!")
        return {'FINISHED'}


def draw_tool(context, layout):
    layout.operator(
        "view3d.camera_from_view_lock",
        text="Create & Lock Camera",
        icon='CAMERA_DATA',
    )


classes = [VIEW3D_OT_camera_from_view_lock]


def register():
    for cls in classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(classes):
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass