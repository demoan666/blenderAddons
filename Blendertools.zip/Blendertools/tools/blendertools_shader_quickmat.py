# tools/blendertools_shader_quickmat.py
#
# Mock tool — Shader Editor context test
# Tests that blendertools panel appears in the Shader Editor and
# NOT in Compositor or 3D View.

TOOL_INFO = {
    "id":              "blendertools_shader_quickmat",
    "version":         "1.0",
    "name":            "Shader Quick Material",
    "context":         "NODE_EDITOR",
    "context_subtype": "ShaderNodeTree",
    "description":     "One-click PBR material starters, quick texture coordinate wiring, and common shader utility setups.",
    "help": (
        "A collection of shader node quick-setup tools.\n\n"
        "PBR STARTER — creates a Principled BSDF wired to the Material Output "
        "with image texture slots ready for albedo, roughness, and normal.\n\n"
        "TEX COORD RIG — adds a Texture Coordinate + Mapping node pair "
        "and wires them up, ready to drive any texture node.\n\n"
        "FRESNEL BLEND — builds a Fresnel-driven MixShader between two "
        "placeholder shaders for quick edge-highlight effects.\n\n"
        "VERTEX COLOR TAP — pulls vertex color data into a shader via "
        "Attribute node, useful for baked or painted masks.\n\n"
        "Note: This is a mock tool for context-system testing. "
        "Buttons report to the Info bar but do not modify your node tree."
    ),
}

import bpy
from bpy.props import FloatProperty, BoolProperty


# -----------------------------------------------------------------------------
# Operators
# -----------------------------------------------------------------------------

class SQMAT_OT_pbr_starter(bpy.types.Operator):
    bl_idname      = "sqmat.pbr_starter"
    bl_label       = "PBR Starter"
    bl_description = "Create a Principled BSDF setup with image texture slots ready to connect"
    bl_options     = {'REGISTER', 'UNDO'}

    def execute(self, context):
        self.report({'INFO'}, "[Mock] PBR starter material created.")
        return {'FINISHED'}


class SQMAT_OT_tex_coord_rig(bpy.types.Operator):
    bl_idname      = "sqmat.tex_coord_rig"
    bl_label       = "Tex Coord Rig"
    bl_description = "Add a Texture Coordinate + Mapping node pair, ready to drive texture nodes"
    bl_options     = {'REGISTER', 'UNDO'}

    def execute(self, context):
        self.report({'INFO'}, "[Mock] Texture Coordinate rig added.")
        return {'FINISHED'}


class SQMAT_OT_fresnel_blend(bpy.types.Operator):
    bl_idname      = "sqmat.fresnel_blend"
    bl_label       = "Fresnel Blend"
    bl_description = "Build a Fresnel-driven MixShader between two placeholder shaders"
    bl_options     = {'REGISTER', 'UNDO'}

    ior: FloatProperty(
        name="IOR",
        description="Index of Refraction for the Fresnel node",
        default=1.45,
        min=1.0,
        max=3.0,
    )

    def execute(self, context):
        self.report({'INFO'}, f"[Mock] Fresnel blend added (IOR {self.ior:.2f}).")
        return {'FINISHED'}


class SQMAT_OT_vertex_color_tap(bpy.types.Operator):
    bl_idname      = "sqmat.vertex_color_tap"
    bl_label       = "Vertex Color Tap"
    bl_description = "Add an Attribute node wired to pull vertex color data into the shader"
    bl_options     = {'REGISTER', 'UNDO'}

    def execute(self, context):
        self.report({'INFO'}, "[Mock] Vertex Color tap added.")
        return {'FINISHED'}


# -----------------------------------------------------------------------------
# Draw
# -----------------------------------------------------------------------------

def draw_tool(context, layout):
    col = layout.column(align=True)
    col.label(text="Quick Setup:", icon='NODE_MATERIAL')

    box = layout.box()
    b   = box.column(align=True)
    b.operator("sqmat.pbr_starter",       text="PBR Starter",        icon='MATERIAL')
    b.operator("sqmat.tex_coord_rig",     text="Tex Coord Rig",      icon='TEXTURE')
    b.operator("sqmat.fresnel_blend",     text="Fresnel Blend",      icon='SHADING_RENDERED')
    b.operator("sqmat.vertex_color_tap",  text="Vertex Color Tap",   icon='GROUP_VCOL')


# -----------------------------------------------------------------------------
# Registration
# -----------------------------------------------------------------------------

classes = [
    SQMAT_OT_pbr_starter,
    SQMAT_OT_tex_coord_rig,
    SQMAT_OT_fresnel_blend,
    SQMAT_OT_vertex_color_tap,
]


def register():
    for cls in classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(classes):
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass
