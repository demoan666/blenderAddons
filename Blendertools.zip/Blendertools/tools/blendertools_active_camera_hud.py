# tools/blendertools_active_camera_hud.py

TOOL_INFO = {
    "id":              "blendertools_active_camera_hud",
    "version":         "1.0",
    "name":            "Active Camera HUD",
    "context":         "VIEW_3D",
    "description":     "Viewport HUD showing the active Render Camera (marker-aware) and current View Camera, with corner and font controls.",
    "help": (
        "Displays a non-intrusive Heads-Up Display in your 3D viewport.\n\n"
        "It dynamically shows the active Render Camera (respecting timeline markers) "
        "and your current Viewport Camera.\n\n"
        "Customize the HUD corner position, font size, and whether it stays visible "
        "even when Blender's standard overlays are hidden."
    ),
}

import bpy
import blf
import gpu
import traceback
from bpy.props import BoolProperty, EnumProperty, IntProperty

_batch_for_shader = None
try:
    from gpu_extras.batch import batch_for_shader as _batch_for_shader
except Exception:
    _batch_for_shader = None

_HANDLE  = None
_FONT_ID = 0


def get_render_camera(scene, frame):
    best, best_frame = None, -10**9
    for m in scene.timeline_markers:
        cam = getattr(m, "camera", None)
        if cam and m.frame <= frame and m.frame >= best_frame:
            best, best_frame = cam, m.frame
    return best if best else scene.camera


def _draw_box(x, y, w, h, a=0.45):
    if not _batch_for_shader:
        return False
    try:
        shader = gpu.shader.from_builtin('UNIFORM_COLOR')
        coords = [(x, y), (x + w, y), (x + w, y + h), (x, y + h)]
        batch  = _batch_for_shader(shader, 'TRI_FAN', {"pos": coords})
        gpu.state.blend_set('ALPHA')
        shader.bind()
        shader.uniform_float("color", (0, 0, 0, a))
        batch.draw(shader)
        gpu.state.blend_set('NONE')
        return True
    except Exception:
        return False


def draw_hud():
    wm = bpy.context.window_manager
    if not wm.active_cam_hud_enable:
        return

    area   = bpy.context.area
    space  = bpy.context.space_data
    region = bpy.context.region
    if not (area and space and region and isinstance(space, bpy.types.SpaceView3D)):
        return

    if not wm.active_cam_hud_ignore_overlay:
        ov = getattr(space, "overlay", None)
        if ov and not ov.show_overlays:
            return

    scene = bpy.context.scene
    frame = scene.frame_current

    rcam  = get_render_camera(scene, frame)
    rname = rcam.name if rcam else "None"

    view_cam    = space.camera if getattr(space, "camera", None) else scene.camera
    in_cam_view = (
        getattr(space, "region_3d", None)
        and space.region_3d.view_perspective == 'CAMERA'
    )
    vname = (view_cam.name if view_cam else "None") + (" (view)" if in_cam_view else "")

    fontsize = wm.active_cam_hud_fontsize
    blf.size(_FONT_ID, fontsize)
    lines   = [f"Render Cam: {rname}", f"View Cam: {vname}"]
    pad     = 8
    widths  = [blf.dimensions(_FONT_ID, ln)[0] for ln in lines]
    heights = [blf.dimensions(_FONT_ID, ln)[1] for ln in lines]
    box_w   = int(max(widths)) + pad * 2
    line_h  = int(max(heights) if heights else fontsize)
    box_h   = int(line_h * len(lines) + pad * 2)

    rx, ry = region.width, region.height
    corner = wm.active_cam_hud_corner
    if corner == 'TL':
        bx, by = 20, ry - box_h - 20
    elif corner == 'TR':
        bx, by = rx - box_w - 20, ry - box_h - 20
    elif corner == 'BL':
        bx, by = 20, 20
    else:
        bx, by = rx - box_w - 20, 20

    _draw_box(bx, by, box_w, box_h)

    ty = by + box_h - pad - line_h
    for line in lines:
        blf.position(_FONT_ID, bx + pad, ty, 0)
        blf.draw(_FONT_ID, line)
        ty -= line_h


def add_handler():
    global _HANDLE
    if _HANDLE is None:
        _HANDLE = bpy.types.SpaceView3D.draw_handler_add(
            draw_hud, (), 'WINDOW', 'POST_PIXEL'
        )


def remove_handler():
    global _HANDLE
    if _HANDLE is not None:
        try:
            bpy.types.SpaceView3D.draw_handler_remove(_HANDLE, 'WINDOW')
        except Exception:
            traceback.print_exc()
        _HANDLE = None


def enable_update(self, context):
    if context.window_manager.active_cam_hud_enable:
        add_handler()
    else:
        remove_handler()


def draw_tool(context, layout):
    wm  = context.window_manager
    col = layout.column(align=True)
    col.prop(wm, "active_cam_hud_enable",       text="Enable HUD")
    col.prop(wm, "active_cam_hud_corner",        text="Corner")
    col.prop(wm, "active_cam_hud_fontsize",       text="Font Size")
    col.prop(wm, "active_cam_hud_ignore_overlay", text="Ignore Overlays Toggle")


def register():
    bpy.types.WindowManager.active_cam_hud_enable = BoolProperty(
        name="Enable HUD",
        description="Show or hide the camera HUD overlay in the 3D viewport",
        default=True,
        update=enable_update,
    )
    bpy.types.WindowManager.active_cam_hud_corner = EnumProperty(
        name="HUD Corner",
        description="Which corner of the viewport to display the HUD in",
        items=[
            ('TL', 'Top-Left',     'Place HUD in the top-left corner'),
            ('TR', 'Top-Right',    'Place HUD in the top-right corner'),
            ('BL', 'Bottom-Left',  'Place HUD in the bottom-left corner'),
            ('BR', 'Bottom-Right', 'Place HUD in the bottom-right corner'),
        ],
        default='BR',
    )
    bpy.types.WindowManager.active_cam_hud_fontsize = IntProperty(
        name="Font Size",
        description="Size of the HUD text in points",
        default=16,
        min=8,
        max=64,
    )
    bpy.types.WindowManager.active_cam_hud_ignore_overlay = BoolProperty(
        name="Ignore Overlays Toggle",
        description="Keep the HUD visible even when viewport overlays are disabled",
        default=True,
    )
    add_handler()


def unregister():
    remove_handler()
    for prop in (
        "active_cam_hud_enable",
        "active_cam_hud_corner",
        "active_cam_hud_fontsize",
        "active_cam_hud_ignore_overlay",
    ):
        if hasattr(bpy.types.WindowManager, prop):
            try:
                delattr(bpy.types.WindowManager, prop)
            except Exception:
                pass