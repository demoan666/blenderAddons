# tools/blendertools_quick_aspect_camera.py

TOOL_INFO = {
    "id":          "blendertools_quick_aspect_camera",
    "version":     "1.0",
    "name":        "Quick Aspect + Camera",
    "context":     "VIEW_3D",
    "description": "One-click presets with scene duplication, intelligent selection parsing, and fallback warnings.",
}

import bpy
import os
import re
import time
from bpy.props import EnumProperty, StringProperty, BoolProperty, IntProperty

PRESETS = {
    "1080x1080": (1080, 1080),
    "1920x1080": (1920, 1080),
    "1080x1920": (1080, 1920),
    "1080x1350": (1080, 1350),
    "1200x1200": (1200, 1200),
    "1200x630":  (1200, 630),
    "1200x627":  (1200, 627),
    "1440x1080": (1440, 1080),
    "Custom":    (None, None),
}

IMAGE_FORMATS = [
    ('PNG', 'PNG', ''), ('JPEG', 'JPEG', ''), ('BMP', 'BMP', ''),
    ('TIFF', 'TIFF', ''), ('WEBP', 'WEBP', ''), ('OPEN_EXR', 'OpenEXR', ''),
    ('OPEN_EXR_MULTILAYER', 'OpenEXR Multilayer', ''), ('HDR', 'Radiance HDR', ''),
    ('JPEG2000', 'JPEG 2000', ''), ('TARGA', 'Targa', ''), ('TARGA_RAW', 'Targa Raw', ''),
    ('CINEON', 'Cineon', ''), ('DPX', 'DPX', ''), ('IRIS', 'Iris (RGB)', ''),
]

EXT_MAP = {
    'PNG': 'png', 'JPEG': 'jpg', 'BMP': 'bmp', 'TIFF': 'tif', 'WEBP': 'webp',
    'OPEN_EXR': 'exr', 'OPEN_EXR_MULTILAYER': 'exr', 'HDR': 'hdr', 'JPEG2000': 'jp2',
    'TARGA': 'tga', 'TARGA_RAW': 'tga', 'CINEON': 'cin', 'DPX': 'dpx', 'IRIS': 'rgb',
}

# -----------------------------------------------------------------------------
# Utility Functions
# -----------------------------------------------------------------------------
def get_lookat_target(cam):
    if not cam: return None
    for con in cam.constraints:
        if con.type in {'TRACK_TO', 'DAMPED_TRACK'} and con.target:
            return con.target
    return None

def _set_resolution(scene, x, y):
    r = scene.render
    r.resolution_x = x
    r.resolution_y = y
    r.resolution_percentage = 100

def _sanitize(s: str):
    return re.sub(r"[^\w\-]+", "_", s).strip("_")

def _resolve_tokens(scene, preset_tag: str, cam_name: str):
    blendname = _sanitize(os.path.splitext(bpy.path.basename(bpy.data.filepath or "untitled.blend"))[0] or "untitled")
    scene_name = _sanitize(scene.name)
    cam_clean = _sanitize(cam_name or "Camera")
    now = time.localtime()
    date = f"{now.tm_year:04d}{now.tm_mon:02d}{now.tm_mday:02d}"
    tm = f"{now.tm_hour:02d}{now.tm_min:02d}{now.tm_sec:02d}"
    return {
        "blendname": blendname, "scene": scene_name, "camera": cam_clean,
        "preset": preset_tag, "date": date, "time": tm,
    }

def _format_filename(template: str, tokens: dict):
    try: return template.format(**tokens)
    except Exception: return "{blendname}_{scene}_{preset}_{camera}".format(**tokens)

def _ensure_dir(path):
    try: os.makedirs(path, exist_ok=True)
    except Exception: pass

def _ext_for_format(scene, forced_fmt: str | None = None):
    fmt = forced_fmt or scene.render.image_settings.file_format or 'PNG'
    return "." + EXT_MAP.get(fmt, 'png')

def _candidate_file(scene, base_dir, base_name, is_animation=False, forced_fmt: str | None = None):
    ext = _ext_for_format(scene, forced_fmt)
    if is_animation: return os.path.join(base_dir, base_name + "0001" + ext)
    return os.path.join(base_dir, base_name + ext)

def _next_version_name(base_name: str):
    m = re.search(r"_v(\d+)$", base_name)
    if m:
        n = int(m.group(1)) + 1
        return re.sub(r"_v\d+$", f"_v{n:02d}", base_name)
    return base_name + "_v01"

def _set_output_path(scene, preset_tag: str, cam_name: str, policy: str, root: str, filename_template: str, forced_fmt: str | None):
    tokens = _resolve_tokens(scene, preset_tag, cam_name)
    base_filename = _sanitize(_format_filename(filename_template, tokens)) or "render"
    if not base_filename.endswith(("_", "-", ".")): base_filename += "_"

    root_abs = bpy.path.abspath((root or "//../Renders/").strip())
    final_dir = os.path.join(root_abs, tokens["blendname"], tokens["preset"])
    _ensure_dir(final_dir)

    is_anim = scene.frame_start != scene.frame_end
    cand = _candidate_file(scene, final_dir, base_filename, is_animation=is_anim, forced_fmt=forced_fmt)
    
    if os.path.exists(cand):
        if policy == 'CANCEL': return (False, f"Existing file detected, path unchanged: {cand}")
        elif policy == 'AUTO_SUFFIX':
            bn, tries = base_filename, 0
            while os.path.exists(_candidate_file(scene, final_dir, bn, is_animation=is_anim, forced_fmt=forced_fmt)) and tries < 200:
                bn, tries = _next_version_name(bn), tries + 1
            base_filename = bn
        elif policy == 'PROMPT':
            sc = scene
            sc.qac21_conflict_dir, sc.qac21_conflict_base, sc.qac21_conflict_anim = final_dir, base_filename, "1" if is_anim else "0"
            bpy.ops.qac21.conflict_dialog('INVOKE_DEFAULT')
            return (True, "Prompting for overwrite decision…")
        elif policy == 'OVERWRITE_ONCE': pass

    target = os.path.join(final_dir, base_filename)
    scene.render.filepath = bpy.path.relpath(target) if root.startswith("//") else target
    return (True, f"Output path set: {scene.render.filepath}")

# -----------------------------------------------------------------------------
# Operators
# -----------------------------------------------------------------------------
class QAC21_OT_conflict_dialog(bpy.types.Operator):
    bl_idname = "qac21.conflict_dialog"
    bl_label = "Output Conflict"
    
    custom_name: StringProperty(name="Custom Name", default="")

    def draw(self, context):
        layout = self.layout
        sc = context.scene
        dirpath = sc.qac21_conflict_dir
        basename = sc.qac21_conflict_base
        is_anim = (sc.qac21_conflict_anim == "1")
        ext = _ext_for_format(sc, sc.qac21_forced_format if sc.qac21_force_format else None)
        sample_path = os.path.join(dirpath, basename + (("0001" if is_anim else "") + ext))
        
        layout.label(text="A file already exists at the target location:")
        col = layout.column(align=True)
        col.label(text=bpy.path.relpath(sample_path) if sample_path.startswith(bpy.path.abspath("//")) else sample_path)
        layout.separator(factor=0.5)
        layout.label(text="Choose an action:")
        box = layout.box()
        box.label(text="A. Add Suffix (recommended)")
        box.label(text="B. Cancel")
        box.label(text="C. Custom Name")
        box.label(text="D. Overwrite (this render only)")
        layout.prop(self, "custom_name", text="Custom Name")

    def invoke(self, context, event):
        self.custom_name = _next_version_name(context.scene.qac21_conflict_base)
        return context.window_manager.invoke_props_dialog(self, width=450)

    def execute(self, context):
        sc = context.scene
        dirpath, base = sc.qac21_conflict_dir, sc.qac21_conflict_base

        if self.custom_name.strip() == base: final_base = base
        elif self.custom_name.strip(): final_base = _sanitize(self.custom_name.strip())
        else: final_base = _next_version_name(base)

        target = os.path.join(dirpath, final_base)
        sc.render.filepath = bpy.path.relpath(target) if bpy.path.abspath("//") in dirpath else target
        self.report({'INFO'}, f"Output path set: {sc.render.filepath}")
        return {'FINISHED'}

class QAC21_OT_apply_preset(bpy.types.Operator):
    bl_idname = "qac21.apply_preset"
    bl_label = "Apply Aspect Preset V2.1"
    bl_options = {'REGISTER', 'UNDO'}

    preset: StringProperty()
    src_cam_name: StringProperty(default="")
    src_lookat_name: StringProperty(default="")
    warning_msg: StringProperty(default="")
    has_lookat: BoolProperty(default=False)
    
    name_mode: EnumProperty(
        name="Camera & Target Naming",
        items=[('AUTO', 'Auto Name', ''), ('MANUAL', 'Manual Name', '')], default='AUTO'
    )
    cam_name: StringProperty(name="Camera Name", default="Cam_Name")
    lookat_name: StringProperty(name="Lookat Name", default="Cam_Lookat_Name")

    scene_mode: EnumProperty(
        name="Scene Options",
        items=[('NEW', 'New Scene (Full Copy)', ''), ('SAME', 'Current Scene', '')], default='NEW'
    )

    def invoke(self, context, event):
        sc = context.scene
        if not sc.qac21_do_aspect and not sc.qac21_do_camera and not sc.qac21_auto_output:
            self.report({'WARNING'}, "Please enable at least one Pick Mode option.")
            return {'CANCELLED'}
        
        sel_cams = [o for o in context.selected_objects if o.type == 'CAMERA']
        sel_empties = [o for o in context.selected_objects if o.type != 'CAMERA']
        base_cam = context.active_object if context.active_object in sel_cams else (sel_cams[0] if sel_cams else None)
        base_lookat = context.active_object if context.active_object in sel_empties else (sel_empties[0] if sel_empties else None)

        self.src_cam_name, self.src_lookat_name, self.warning_msg = "", "", ""
        
        if base_cam and base_lookat:
            self.src_cam_name, self.src_lookat_name = base_cam.name, base_lookat.name
        elif base_cam and not base_lookat:
            self.src_cam_name = base_cam.name
            tgt = get_lookat_target(base_cam)
            if tgt: self.src_lookat_name = tgt.name
        elif not base_cam and base_lookat:
            found_cam = next((obj for obj in sc.objects if obj.type == 'CAMERA' and get_lookat_target(obj) == base_lookat), None)
            if found_cam: self.src_cam_name, self.src_lookat_name = found_cam.name, base_lookat.name
        
        if not self.src_cam_name:
            if sc.camera:
                self.src_cam_name = sc.camera.name
                tgt = get_lookat_target(sc.camera)
                if tgt: self.src_lookat_name = tgt.name
                if sc.qac21_do_camera: self.warning_msg = "No camera selected! Proceed based on Active Render Camera?"
            else:
                if sc.qac21_do_camera:
                    context.window_manager.popup_menu(lambda s,c: s.layout.label(text="Please select a camera.", icon='ERROR'), title="No Camera", icon='ERROR')
                    return {'CANCELLED'}

        self.has_lookat = bool(self.src_lookat_name)
        lbl = f"{sc.qac21_custom_x}x{sc.qac21_custom_y}" if self.preset == "Custom" else self.preset
        self.cam_name, self.lookat_name = f"Cam_{lbl}", f"Cam_Lookat_{lbl}"
        self.name_mode, self.scene_mode = 'AUTO', 'NEW'

        return context.window_manager.invoke_props_dialog(self, width=350)

    def draw(self, context):
        sc = context.scene
        layout = self.layout
        layout.use_property_split = False
        
        lbl = f"{sc.qac21_custom_x}x{sc.qac21_custom_y} (Custom)" if self.preset == "Custom" else self.preset
        row_hdr = layout.row(); row_hdr.alignment = 'CENTER'; row_hdr.label(text=f"--- Preset: {lbl} ---", icon='RENDER_RESULT')
        layout.separator()
        
        box_info = layout.box()
        if self.warning_msg:
            box_info.alert = True; box_info.label(text=self.warning_msg, icon='ERROR')
        else:
            col_info = box_info.column(align=True)
            if sc.qac21_do_camera:
                if self.src_cam_name: col_info.label(text=f"Base Camera: {self.src_cam_name}", icon='CAMERA_DATA')
                if self.src_lookat_name: col_info.label(text=f"Base Lookat: {self.src_lookat_name}", icon='EMPTY_DATA')
            else:
                active_tasks = [t for c,t in ((sc.qac21_do_aspect, "Aspect Ratio"), (sc.qac21_auto_output, "Output Path")) if c]
                col_info.label(text=f"Action: Update {' & '.join(active_tasks)} only", icon='CHECKMARK')
            
        boxA = layout.box()
        boxA.enabled = sc.qac21_do_camera
        boxA.label(text="Section A: Naming", icon='OUTLINER_OB_CAMERA')
        colA = boxA.column()
        colA.prop(self, "name_mode", expand=True)
        colA_sub = colA.column(align=True); colA_sub.enabled = (self.name_mode == 'MANUAL')
        colA_sub.prop(self, "cam_name", text="Camera")
        if self.has_lookat: colA_sub.prop(self, "lookat_name", text="Lookat")
            
        layout.separator()
        boxB = layout.box()
        boxB.enabled = sc.qac21_do_camera
        boxB.label(text="Section B: Scene", icon='SCENE_DATA')
        boxB.column().prop(self, "scene_mode", expand=True)

    def execute(self, context):
        sc = context.scene
        x, y = (sc.qac21_custom_x, sc.qac21_custom_y) if self.preset == "Custom" else PRESETS[self.preset]
        lbl = f"{x}x{y}" if self.preset == "Custom" else self.preset

        orig_cam = sc.objects.get(self.src_cam_name) if self.src_cam_name else None
        orig_target = sc.objects.get(self.src_lookat_name) if self.src_lookat_name else None
        
        if sc.qac21_do_camera and not orig_cam:
            self.report({'ERROR'}, "Source camera missing."); return {'CANCELLED'}
                    
        c_name = self.cam_name if self.name_mode == 'MANUAL' else f"Cam_{lbl}"
        t_name = self.lookat_name if self.name_mode == 'MANUAL' else f"Cam_Lookat_{lbl}"
        new_cam, new_scene = None, sc

        if sc.qac21_do_camera:
            if self.scene_mode == 'NEW':
                bpy.ops.scene.new(type='FULL_COPY')
                new_scene = context.scene; new_scene.name = f"Scene_{lbl}"
                new_cam, new_target = new_scene.objects.get(orig_cam.name), (new_scene.objects.get(orig_target.name) if orig_target else None)
                if new_cam:
                    new_cam.name = c_name
                    if new_target:
                        new_target.name = t_name
                        has_con = False
                        for con in new_cam.constraints:
                            if con.type in {'TRACK_TO', 'DAMPED_TRACK'}: con.target, has_con = new_target, True; break
                        if not has_con:
                            con = new_cam.constraints.new(type='TRACK_TO'); con.target, con.track_axis, con.up_axis = new_target, 'TRACK_NEGATIVE_Z', 'UP_Y'
            else:
                new_cam = orig_cam.copy(); new_cam.data = orig_cam.data.copy()
                new_scene.collection.objects.link(new_cam); new_cam.name = c_name
                if orig_target:
                    new_target = orig_target.copy()
                    if orig_target.data: new_target.data = orig_target.data.copy()
                    new_scene.collection.objects.link(new_target); new_target.name = t_name
                    has_con = False
                    for con in new_cam.constraints:
                        if con.type in {'TRACK_TO', 'DAMPED_TRACK'}: con.target, has_con = new_target, True; break
                    if not has_con:
                        con = new_cam.constraints.new(type='TRACK_TO'); con.target, con.track_axis, con.up_axis = new_target, 'TRACK_NEGATIVE_Z', 'UP_Y'
                new_scene.camera = new_cam
        else: new_cam = orig_cam

        if sc.qac21_do_aspect: _set_resolution(new_scene, x, y)
        
        forced_fmt = new_scene.qac21_forced_format if new_scene.qac21_force_format else None
        if forced_fmt: new_scene.render.image_settings.file_format = forced_fmt

        if new_scene.qac21_auto_output:
            ok, msg = _set_output_path(new_scene, lbl, new_cam.name if new_cam else "Camera", new_scene.qac21_overwrite_policy, new_scene.qac21_root_folder, new_scene.qac21_filename_template, forced_fmt)
            self.report({'INFO'}, msg)

        return {'FINISHED'}

# -----------------------------------------------------------------------------
# Tool UI (Called dynamically by Stack System)
# -----------------------------------------------------------------------------
def draw_tool(context, layout):
    sc = context.scene

    # --- Pick Mode ---
    box_pick = layout.box()
    row_pick_header = box_pick.row()
    row_pick_header.label(text="Pick Mode", icon='VIEW_PAN')
    
    row_pick = box_pick.row(align=True)
    row_pick.prop(sc, "qac21_do_camera", text="Camera", toggle=True)
    row_pick.prop(sc, "qac21_do_aspect", text="Aspects Ratio", toggle=True)
    row_pick.prop(sc, "qac21_auto_output", text="Output", toggle=True)
    
    layout.separator()
    
    # --- Quick Camera / Aspect Presets ---
    box_p = layout.box()
    box_p.label(text="Quick Camera / Aspect Presets", icon='CAMERA_DATA')
    col_p = box_p.column(align=True)
    
    p_keys = list(PRESETS.keys())
    p_keys.remove("Custom")
    
    for i in range(0, len(p_keys), 2):
        row = col_p.row(align=True)
        row.operator("qac21.apply_preset", text=p_keys[i]).preset = p_keys[i]
        if i + 1 < len(p_keys): row.operator("qac21.apply_preset", text=p_keys[i+1]).preset = p_keys[i+1]
            
    col_p.separator()
    row_c = col_p.row(align=True)
    row_c.prop(sc, "qac21_custom_x", text="")
    row_c.prop(sc, "qac21_custom_y", text="")
    row_c.operator("qac21.apply_preset", text="Custom").preset = "Custom"
    
    layout.separator()

    # --- Quick Output Details ---
    box_o = layout.box()
    box_o.label(text="Quick Output Details", icon='OUTPUT')
    col_o = box_o.column(align=True)
    col_o.enabled = sc.qac21_auto_output
    
    row_f = col_o.row(align=True)
    row_f.prop(sc, "qac21_force_format", text="Force Format")
    sub_f = row_f.row(align=True)
    sub_f.enabled = sc.qac21_force_format
    sub_f.prop(sc, "qac21_forced_format", text="")
        
    col_o.separator()
    col_o.prop(sc, "qac21_root_folder", text="Root Folder")
    col_o.prop(sc, "qac21_filename_template", text="Filename Template")
    col_o.prop(sc, "qac21_overwrite_policy", text="Overwrite Policy")

# -----------------------------------------------------------------------------
# Registration
# -----------------------------------------------------------------------------
classes = (
    QAC21_OT_conflict_dialog,
    QAC21_OT_apply_preset,
)

def register():
    for c in classes: bpy.utils.register_class(c)
    bpy.types.Scene.qac21_custom_x = IntProperty(name="Custom X", default=1080, min=2)
    bpy.types.Scene.qac21_custom_y = IntProperty(name="Custom Y", default=1080, min=2)
    bpy.types.Scene.qac21_do_aspect = BoolProperty(name="Set Asp Ratio", default=True)
    bpy.types.Scene.qac21_do_camera = BoolProperty(name="Create Camera", default=True)
    bpy.types.Scene.qac21_auto_output = BoolProperty(name="Auto Output Path", default=True)
    bpy.types.Scene.qac21_root_folder = StringProperty(name="Root Folder", default="//../Renders/", subtype='DIR_PATH')
    bpy.types.Scene.qac21_filename_template = StringProperty(name="Filename Template", default="{blendname}_{preset}_")
    bpy.types.Scene.qac21_overwrite_policy = EnumProperty(
        name="Overwrite Policy",
        items=(('PROMPT', "Prompt", ""), ('AUTO_SUFFIX', "Auto-suffix", ""), ('CANCEL', "Cancel", ""), ('OVERWRITE_ONCE', "Overwrite", "")),
        default='PROMPT',
    )
    bpy.types.Scene.qac21_force_format = BoolProperty(name="Force Format", default=True)
    bpy.types.Scene.qac21_forced_format = EnumProperty(name="Format", items=IMAGE_FORMATS, default='PNG')
    bpy.types.Scene.qac21_conflict_dir = StringProperty(default="")
    bpy.types.Scene.qac21_conflict_base = StringProperty(default="")
    bpy.types.Scene.qac21_conflict_anim = StringProperty(default="0")

def unregister():
    for attr in ("qac21_custom_x", "qac21_custom_y", "qac21_do_aspect", "qac21_do_camera", "qac21_auto_output", "qac21_root_folder", "qac21_filename_template", "qac21_overwrite_policy", "qac21_force_format", "qac21_forced_format", "qac21_conflict_dir", "qac21_conflict_base", "qac21_conflict_anim"):
        try: delattr(bpy.types.Scene, attr)
        except Exception: pass
    for c in reversed(classes):
        try: bpy.utils.unregister_class(c)
        except Exception: pass