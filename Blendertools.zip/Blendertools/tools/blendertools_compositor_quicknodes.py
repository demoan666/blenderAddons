# tools/blendertools_compositor_quicknodes.py
#
# Mock tool — Compositor context test
# Tests that blendertools panel appears in the Compositor and
# NOT in 3D View or Shader Editor.

TOOL_INFO = {
    "id":              "blendertools_compositor_quicknodes",
    "version":         "1.0",
    "name":            "Compositor Quick Nodes",
    "context":         "NODE_EDITOR",
    "context_subtype": "CompositorNodeTree",
    "description":     "Quick-add common compositor node setups: glare, lens distortion, color grading chains, and viewer wiring.",
    "help": (
        "A collection of one-click compositor node presets.\n\n"
        "GLARE — adds a Glare node wired between Render Layers and Composite "
        "with sensible streak defaults.\n\n"
        "LENS DISTORT — inserts a Lens Distortion node with a subtle barrel "
        "distortion preset.\n\n"
        "COLOR GRADE — builds a basic color grading chain: "
        "Color Balance → Hue Saturation Value → Composite.\n\n"
        "VIEWER TAP — wires a Viewer node off the currently selected node's "
        "first image output so you can preview it instantly.\n\n"
        "Note: This is a mock tool for context-system testing. "
        "Buttons report to the Info bar but do not modify your node tree."
    ),
}

import bpy
from bpy.props import EnumProperty


# -----------------------------------------------------------------------------
# Operators
# -----------------------------------------------------------------------------

class CQNODE_OT_add_glare(bpy.types.Operator):
    bl_idname      = "cqnode.add_glare"
    bl_label       = "Add Glare Setup"
    bl_description = "Insert a pre-configured Glare node into the compositor tree"
    bl_options     = {'REGISTER', 'UNDO'}

    def execute(self, context):
        self.report({'INFO'}, "[Mock] Glare node setup added.")
        return {'FINISHED'}


class CQNODE_OT_add_lens_distort(bpy.types.Operator):
    bl_idname      = "cqnode.add_lens_distort"
    bl_label       = "Add Lens Distortion"
    bl_description = "Insert a Lens Distortion node with barrel distortion preset"
    bl_options     = {'REGISTER', 'UNDO'}

    def execute(self, context):
        self.report({'INFO'}, "[Mock] Lens Distortion node added.")
        return {'FINISHED'}


class CQNODE_OT_add_color_grade(bpy.types.Operator):
    bl_idname      = "cqnode.add_color_grade"
    bl_label       = "Add Color Grade Chain"
    bl_description = "Build a Color Balance → Hue Saturation → Composite node chain"
    bl_options     = {'REGISTER', 'UNDO'}

    def execute(self, context):
        self.report({'INFO'}, "[Mock] Color grade chain added.")
        return {'FINISHED'}


class CQNODE_OT_viewer_tap(bpy.types.Operator):
    bl_idname      = "cqnode.viewer_tap"
    bl_label       = "Viewer Tap"
    bl_description = "Wire a Viewer node off the selected node's first image output"
    bl_options     = {'REGISTER', 'UNDO'}

    def execute(self, context):
        self.report({'INFO'}, "[Mock] Viewer node tapped.")
        return {'FINISHED'}


# -----------------------------------------------------------------------------
# Draw
# -----------------------------------------------------------------------------

def draw_tool(context, layout):
    col = layout.column(align=True)
    col.label(text="Quick Add:", icon='NODE_COMPOSITING')

    box = layout.box()
    b   = box.column(align=True)
    b.operator("cqnode.add_glare",         text="Glare Setup",        icon='LIGHT_SUN')
    b.operator("cqnode.add_lens_distort",  text="Lens Distortion",    icon='MOD_MESHDEFORM')
    b.operator("cqnode.add_color_grade",   text="Color Grade Chain",  icon='IMAGE_RGB')

    layout.separator()
    layout.operator("cqnode.viewer_tap",   text="Viewer Tap",         icon='HIDE_OFF')


# -----------------------------------------------------------------------------
# Registration
# -----------------------------------------------------------------------------

classes = [
    CQNODE_OT_add_glare,
    CQNODE_OT_add_lens_distort,
    CQNODE_OT_add_color_grade,
    CQNODE_OT_viewer_tap,
]


def register():
    for cls in classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(classes):
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass
