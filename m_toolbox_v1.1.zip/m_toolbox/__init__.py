# m_toolbox/__init__.py
bl_info = {
    "name": "m Toolbox",
    "author": "m",
    "version": (1, 0, 1),
    "blender": (5, 0, 0),
    "location": "Edit > Preferences > Add-ons > m Toolbox",
    "description": "Install once, then drop .py tool files into tools/ and hot-reload them.",
    "category": "System",
}

import bpy, os, sys, json, importlib, traceback

ADDON_DIR = os.path.dirname(__file__)
TOOLS_DIR = os.path.join(ADDON_DIR, "tools")
if TOOLS_DIR not in sys.path:
    sys.path.append(TOOLS_DIR)

_LOADED = {}
_SCANNED = []

def ensure_tools_dir():
    try: os.makedirs(TOOLS_DIR, exist_ok=True)
    except Exception: pass

def list_tool_files():
    ensure_tools_dir()
    names = []
    for fn in os.listdir(TOOLS_DIR):
        if fn.endswith(".py") and not fn.startswith("_"):
            names.append(os.path.splitext(fn)[0])
    names.sort()
    return names

def read_tool_meta(mod):
    meta = {"id": getattr(mod, "__name__", "unknown"), "name": getattr(mod, "__name__", "unknown")}
    ti = getattr(mod, "TOOL_INFO", None)
    if isinstance(ti, dict):
        for k in ("id","name","description"):
            if k in ti: meta[k] = ti[k]
        if "name" not in meta: meta["name"] = meta["id"]
    return meta

def prefs():
    try: return bpy.context.preferences.addons[__package__].preferences
    except Exception: return None

def _load_enabled_set(pref_obj):
    if not pref_obj: return set()
    try: return set(json.loads(pref_obj.enabled_tools_json))
    except Exception: return set()

def _save_enabled_set(pref_obj, enabled_set):
    if pref_obj: pref_obj.enabled_tools_json = json.dumps(sorted(enabled_set))

def log_popup(title, message):
    def draw(self, context):
        for line in message.splitlines():
            self.layout.label(text=line)
    try: bpy.context.window_manager.popup_menu(draw, title=title, icon='INFO')
    except Exception: print(f"[m_toolbox] {title}: {message}")

def enable_tool(mod_name, silent=False):
    if mod_name in _LOADED: return True
    try:
        mod = importlib.import_module(mod_name); importlib.reload(mod)
        if hasattr(mod, "register"): mod.register()
        _LOADED[mod_name] = mod
        if not silent: print(f"[m_toolbox] Enabled: {mod_name}")
        return True
    except Exception as e:
        traceback.print_exc(); log_popup("Enable Tool Failed", f"{mod_name}\n{e}"); return False

def disable_tool(mod_name, silent=False):
    mod = _LOADED.get(mod_name)
    if not mod: return True
    try:
        if hasattr(mod, "unregister"): mod.unregister()
    except Exception as e:
        traceback.print_exc(); log_popup("Disable Tool Error", f"{mod_name}\n{e}")
    _LOADED.pop(mod_name, None)
    try: sys.modules.pop(mod_name, None)
    except Exception: pass
    if not silent: print(f"[m_toolbox] Disabled: {mod_name}")
    return True

def rescan_tools():
    global _SCANNED; _SCANNED = list_tool_files(); return list(_SCANNED)

def reload_enabled():
    p = prefs(); enabled = _load_enabled_set(p)
    for name in list(enabled):
        if name in _LOADED:
            try:
                if hasattr(_LOADED[name], "unregister"): _LOADED[name].unregister()
            except Exception: traceback.print_exc()
        try:
            mod = importlib.import_module(name); importlib.reload(mod)
            if hasattr(mod, "register"): mod.register()
            _LOADED[name] = mod
        except Exception as e:
            traceback.print_exc(); log_popup("Reload Failed", f"{name}\n{e}")

class MTB_OT_toggle_tool(bpy.types.Operator):
    bl_idname = "mtb.toggle_tool"
    bl_label = "Enable/Disable Tool"
    tool: bpy.props.StringProperty()
    def execute(self, context):
        p = prefs(); enabled = _load_enabled_set(p)
        if self.tool in enabled: disable_tool(self.tool); enabled.discard(self.tool)
        else:
            if enable_tool(self.tool): enabled.add(self.tool)
        _save_enabled_set(p, enabled); return {'FINISHED'}

class MTB_OT_rescan(bpy.types.Operator):
    bl_idname = "mtb.rescan"; bl_label = "Rescan Tools Folder"
    def execute(self, context): rescan_tools(); self.report({'INFO'},"Rescanned tools"); return {'FINISHED'}

class MTB_OT_reload_enabled(bpy.types.Operator):
    bl_idname = "mtb.reload_enabled"; bl_label = "Reload Enabled Tools"
    def execute(self, context): reload_enabled(); self.report({'INFO'},"Reloaded enabled tools"); return {'FINISHED'}

class MTB_OT_open_folder(bpy.types.Operator):
    bl_idname = "mtb.open_tools_folder"; bl_label = "Open Tools Folder"
    def execute(self, context): ensure_tools_dir(); bpy.ops.wm.path_open(filepath=TOOLS_DIR); return {'FINISHED'}

class MTB_OT_install_from_text(bpy.types.Operator):
    bl_idname = "mtb.install_from_text"; bl_label = "Install Current Text as Tool"
    filename: bpy.props.StringProperty(name="Filename", default="")
    enable_after: bpy.props.BoolProperty(name="Enable after save", default=True)
    def invoke(self, context, event): return context.window_manager.invoke_props_dialog(self, width=420)
    def execute(self, context):
        ensure_tools_dir()
        txt = getattr(bpy.context.space_data, "text", None)
        if not txt or not txt.as_string(): self.report({'ERROR'},"No active text block with content"); return {'CANCELLED'}
        fname = self.filename.strip() or txt.name
        if not fname.endswith(".py"): fname += ".py"
        target = os.path.join(TOOLS_DIR, fname)
        with open(target, "w", encoding="utf-8") as f: f.write(txt.as_string())
        self.report({'INFO'}, f"Saved {fname} to tools/")
        rescan_tools(); base = os.path.splitext(fname)[0]
        if self.enable_after:
            p = prefs(); enabled = _load_enabled_set(p)
            if enable_tool(base): enabled.add(base); _save_enabled_set(p, enabled)
        return {'FINISHED'}

class MTB_AddonPreferences(bpy.types.AddonPreferences):
    bl_idname = __package__
    enabled_tools_json: bpy.props.StringProperty(name="Enabled Tools (internal)", default="[]")
    def draw(self, context):
        layout = self.layout
        layout.label(text="m Toolbox — Manage your mini tools")
        row = layout.row(align=True)
        row.operator("mtb.rescan", icon="FILE_REFRESH")
        row.operator("mtb.reload_enabled", icon="RECOVER_LAST")
        row.operator("mtb.open_tools_folder", icon="FILE_FOLDER")
        row.operator("mtb.install_from_text", icon="TEXT")
        layout.separator()
        box = layout.box(); box.label(text="Tools in Folder:")
        if not _SCANNED:
            box.label(text="(No tools found yet. Click Rescan or drop .py into tools/.)", icon='INFO')
        enabled = _load_enabled_set(self)
        for mod_name in _SCANNED:
            title = mod_name
            try:
                mod = importlib.import_module(mod_name); meta = read_tool_meta(mod)
                title = f"{meta.get('name', mod_name)}  [{mod_name}]"
            except Exception: pass
            row = box.row(align=True)
            row.label(text=title, icon='CHECKBOX_HLT' if mod_name in enabled else 'CHECKBOX_DEHLT')
            op = row.operator("mtb.toggle_tool", text="Disable" if mod_name in enabled else "Enable",
                              icon='X' if mod_name in enabled else 'CHECKMARK')
            op.tool = mod_name

# Fixed: removed walrus operator from tuple literal
classes = (
    MTB_OT_toggle_tool,
    MTB_OT_rescan,
    MTB_OT_reload_enabled,
    MTB_OT_open_folder,
    MTB_OT_install_from_text,
    MTB_AddonPreferences,
)

def register():
    for c in classes: bpy.utils.register_class(c)
    ensure_tools_dir(); rescan_tools()
    try:
        p = prefs()
        for name in _load_enabled_set(p): enable_tool(name, silent=True)
    except Exception: pass
    print("[m_toolbox] Registered.")

def unregister():
    for name in list(_LOADED.keys()):
        try: disable_tool(name, silent=True)
        except Exception: pass
    for c in reversed(classes):
        try: bpy.utils.unregister_class(c)
        except Exception: pass
    print("[m_toolbox] Unregistered.")
