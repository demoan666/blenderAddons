# tools/quick_aspect_camera.py
# Quick Aspect + Camera — multi-preset, auto resolution, optional auto output path with conflict dialog,
# and optional forced image format selection.

TOOL_INFO = {
    "id": "quick_aspect_camera",
    "name": "Quick Aspect + Camera",
    "description": "One-click resolution presets + auto-select camera by suffix/tag, optional auto output path with conflict handling, optional forced image format.",
}

import bpy
import os
import re
import time
from bpy.props import EnumProperty, StringProperty, BoolProperty

# -----------------------------------------------------------------------------
# Root shim so the panel can parent to MTB_PT_root even if the shared root
# panel (from mtb_root_panel.py) hasn't registered yet.
# -----------------------------------------------------------------------------
try:
    _QAC_SHIM_ROOT = not hasattr(bpy.types, "MTB_PT_root")

    if _QAC_SHIM_ROOT:
        class MTB_PT_root(bpy.types.Panel):
            bl_label = "m Toolbox"
            bl_idname = "MTB_PT_root"
            bl_space_type = 'VIEW_3D'
            bl_region_type = 'UI'
            bl_category = 'm Tools'
            def draw(self, context):
                pass
except Exception:
    _QAC_SHIM_ROOT = False

# -------------------------------
# Presets
# -------------------------------
PRESETS = {
    "1080x1080": (1080, 1080),
    "1920x1080": (1920, 1080),
    "1080x1920": (1080, 1920),
    "1080x1350": (1080, 1350),
    "1200x1200": (1200, 1200),
}

# Supported image formats (Blender defaults for stills)
IMAGE_FORMATS = [
    ('PNG', 'PNG', ''),
    ('JPEG', 'JPEG', ''),
    ('BMP', 'BMP', ''),
    ('TIFF', 'TIFF', ''),
    ('WEBP', 'WEBP', ''),
    ('OPEN_EXR', 'OpenEXR', ''),
    ('OPEN_EXR_MULTILAYER', 'OpenEXR Multilayer', ''),
    ('HDR', 'Radiance HDR', ''),
    ('JPEG2000', 'JPEG 2000', ''),
    ('TARGA', 'Targa', ''),
    ('TARGA_RAW', 'Targa Raw', ''),
    ('CINEON', 'Cineon', ''),
    ('DPX', 'DPX', ''),
    ('IRIS', 'Iris (RGB)', ''),
]

EXT_MAP = {
    'PNG': 'png',
    'JPEG': 'jpg',
    'BMP': 'bmp',
    'TIFF': 'tif',
    'WEBP': 'webp',
    'OPEN_EXR': 'exr',
    'OPEN_EXR_MULTILAYER': 'exr',
    'HDR': 'hdr',
    'JPEG2000': 'jp2',
    'TARGA': 'tga',
    'TARGA_RAW': 'tga',
    'CINEON': 'cin',
    'DPX': 'dpx',
    'IRIS': 'rgb',
}

# -------------------------------
# Utilities
# -------------------------------
def _find_camera_for_tag(tag: str):
    # Prefer name suffix match
    for obj in bpy.data.objects:
        if obj.type == 'CAMERA' and obj.name.endswith("_" + tag):
            return obj
    # Fallback: custom prop on object or data
    for obj in bpy.data.objects:
        if obj.type == 'CAMERA' and (obj.get("preset_tag") == tag or obj.data.get("preset_tag") == tag):
            return obj
    return None

def _set_resolution(scene, x, y):
    r = scene.render
    r.resolution_x = x
    r.resolution_y = y
    r.resolution_percentage = 100

def _sanitize(s: str):
    return re.sub(r"[^\w\-]+", "_", s).strip("_")

def _resolve_tokens(scene, preset_tag: str, cam_name: str):
    blendname = _sanitize(os.path.splitext(bpy.path.basename(bpy.data.filepath or "untitled.blend"))[0] or "untitled")
    scene_name = _sanitize(scene.name)
    cam_clean = _sanitize(cam_name or "Camera")
    now = time.localtime()
    date = f"{now.tm_year:04d}{now.tm_mon:02d}{now.tm_mday:02d}"
    tm = f"{now.tm_hour:02d}{now.tm_min:02d}{now.tm_sec:02d}"
    return {
        "blendname": blendname,
        "scene": scene_name,
        "camera": cam_clean,
        "preset": preset_tag,
        "date": date,
        "time": tm,
    }

def _format_filename(template: str, tokens: dict):
    try:
        return template.format(**tokens)
    except Exception:
        return "{blendname}_{scene}_{preset}_{camera}".format(**tokens)

def _ensure_dir(path):
    try:
        os.makedirs(path, exist_ok=True)
    except Exception:
        pass

def _ext_for_format(scene, forced_fmt: str | None = None):
    fmt = forced_fmt or scene.render.image_settings.file_format or 'PNG'
    return "." + EXT_MAP.get(fmt, 'png')

def _candidate_file(scene, base_dir, base_name, is_animation=False, forced_fmt: str | None = None):
    """
    Return a full file path to check for existence.
    For stills: <dir>/<base><ext>
    For animation: <dir>/<base>0001<ext> (approximate check)
    """
    ext = _ext_for_format(scene, forced_fmt)
    if is_animation:
        return os.path.join(base_dir, base_name + "0001" + ext)
    else:
        return os.path.join(base_dir, base_name + ext)

def _next_version_name(base_name: str):
    m = re.search(r"_v(\d+)$", base_name)
    if m:
        n = int(m.group(1)) + 1
        return re.sub(r"_v\d+$", f"_v{n:02d}", base_name)
    else:
        return base_name + "_v01"

def _set_output_path(scene, preset_tag: str, cam_name: str, policy: str, root: str, filename_template: str, forced_fmt: str | None):
    """
    Target path:
        <root>/<blendname>/<preset>/<base>
    base comes from filename_template; we ensure it ends with '_' so frame numbers don't touch the name.
    """
    tokens = _resolve_tokens(scene, preset_tag, cam_name)
    base_filename = _sanitize(_format_filename(filename_template, tokens)) or "render"

    # separator before frame numbers
    if not base_filename.endswith(("_", "-", ".")):
        base_filename += "_"

    root = (root or "//../Renders/").strip()
    root_abs = bpy.path.abspath(root)

    final_dir = os.path.join(root_abs, tokens["blendname"], tokens["preset"])
    _ensure_dir(final_dir)

    is_anim = scene.frame_start != scene.frame_end
    cand = _candidate_file(scene, final_dir, base_filename, is_animation=is_anim, forced_fmt=forced_fmt)
    exists = os.path.exists(cand)

    if exists:
        if policy == 'CANCEL':
            return (False, f"Existing file detected, path unchanged: {cand}")
        elif policy == 'AUTO_SUFFIX':
            bn, tries = base_filename, 0
            while os.path.exists(_candidate_file(scene, final_dir, bn, is_animation=is_anim, forced_fmt=forced_fmt)) and tries < 200:
                bn, tries = _next_version_name(bn), tries + 1
            base_filename = bn
        elif policy == 'PROMPT':
            sc = scene
            sc.qac_conflict_dir = final_dir
            sc.qac_conflict_base = base_filename
            sc.qac_conflict_anim = "1" if is_anim else "0"
            bpy.ops.qac.conflict_dialog('INVOKE_DEFAULT')
            return (True, "Prompting for overwrite decision…")
        elif policy == 'OVERWRITE_ONCE':
            pass

    target = os.path.join(final_dir, base_filename)
    scene.render.filepath = bpy.path.relpath(target) if root.startswith("//") else target
    return (True, f"Output path set: {scene.render.filepath}")

# -------------------------------
# Operators: Conflict dialog
# -------------------------------
class QAC_OT_conflict_dialog(bpy.types.Operator):
    bl_idname = "qac.conflict_dialog"
    bl_label = "Output Conflict"
    bl_description = "Choose how to resolve an existing file at the target path"

    custom_name: StringProperty(name="Custom Name", default="")

    def draw(self, context):
        layout = self.layout
        sc = context.scene
        dirpath = sc.qac_conflict_dir
        basename = sc.qac_conflict_base
        is_anim = (sc.qac_conflict_anim == "1")
        ext = _ext_for_format(sc, sc.qac_forced_format if sc.qac_force_format else None)
        sample_path = os.path.join(dirpath, basename + (("0001" if is_anim else "") + ext))
        layout.label(text="A file already exists at the target location:")
        col = layout.column(align=True)
        col.label(text=bpy.path.relpath(sample_path) if sample_path.startswith(bpy.path.abspath("//")) else sample_path)
        layout.separator(factor=0.5)
        layout.label(text="Choose an action:")
        box = layout.box()
        box.label(text="A. Add Suffix (recommended)")
        box.label(text="B. Cancel")
        box.label(text="C. Custom Name")
        box.label(text="D. Overwrite (this render only)")
        layout.prop(self, "custom_name", text="Custom Name")

    def invoke(self, context, event):
        sc = context.scene
        self.custom_name = _next_version_name(sc.qac_conflict_base)
        return context.window_manager.invoke_props_dialog(self, width=520)

    def execute(self, context):
        sc = context.scene
        dirpath = sc.qac_conflict_dir
        base = sc.qac_conflict_base

        # Overwrite if exact same name; custom if provided; otherwise add suffix
        if self.custom_name.strip() == base:
            final_base = base  # D. Overwrite
        elif self.custom_name.strip():
            final_base = _sanitize(self.custom_name.strip())  # C. Custom
        else:
            final_base = _next_version_name(base)  # A. Add Suffix

        target = os.path.join(dirpath, final_base)
        sc.render.filepath = bpy.path.relpath(target) if bpy.path.abspath("//") in dirpath else target
        self.report({'INFO'}, f"Output path set: {sc.render.filepath}")
        return {'FINISHED'}

    def cancel(self, context):
        self.report({'INFO'}, "Conflict dialog cancelled; output path unchanged.")

# -------------------------------
# Operators: Tag / Duplicate
# -------------------------------
class QAC_OT_tag_active_camera(bpy.types.Operator):
    bl_idname = "qac.tag_active_camera"
    bl_label = "Tag Active Camera for Preset"
    bl_description = "Tag the active camera so buttons can find it even without the suffix."

    preset: EnumProperty(items=[(k, k.replace("x", "×"), '') for k in PRESETS.keys()], name="Preset")

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)

    def execute(self, context):
        cam = context.scene.camera
        if not cam:
            self.report({'WARNING'}, "No active camera to tag.")
            return {'CANCELLED'}
        cam["preset_tag"] = self.preset
        if not cam.name.endswith("_" + self.preset):
            base = cam.name.rsplit("_", 1)[0] if "_" in cam.name else cam.name
            cam.name = f"{base}_{self.preset}"
        self.report({'INFO'}, f"Tagged {cam.name} for {self.preset}")
        return {'FINISHED'}

class QAC_OT_duplicate_for_other_preset(bpy.types.Operator):
    bl_idname = "qac.duplicate_for_other_preset"
    bl_label = "Duplicate Active Camera for Other Preset"
    bl_description = "Clone the active camera and suffix it for the chosen preset."

    target: EnumProperty(items=[(k, k.replace("x", "×"), '') for k in PRESETS.keys()], name="Create")

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)

    def execute(self, context):
        src = context.scene.camera
        if not src:
            self.report({'WARNING'}, "No active camera to duplicate.")
            return {'CANCELLED'}
        new = src.copy()
        new.data = src.data.copy()
        base = src.name.rsplit("_", 1)[0] if "_" in src.name else src.name
        new.name = f"{base}_{self.target}"
        context.collection.objects.link(new)
        new["preset_tag"] = self.target
        self.report({'INFO'}, f"Made {new.name}")
        return {'FINISHED'}

# -------------------------------
# Operator: Apply Preset
# -------------------------------
class QAC_OT_apply_preset(bpy.types.Operator):
    bl_idname = "qac.apply_preset"
    bl_label = "Apply Aspect Preset"
    bl_description = "Set resolution, switch to matching camera, optionally force image format, and optionally set output path."

    preset: EnumProperty(items=[(k, k.replace("x", "×"), '') for k in PRESETS.keys()], name="Preset")

    def execute(self, context):
        sc = context.scene
        x, y = PRESETS[self.preset]
        _set_resolution(sc, x, y)

        # Switch camera by suffix/tag
        cam = _find_camera_for_tag(self.preset)
        if cam:
            sc.camera = cam
            cam_name = cam.name
            msg_cam = f"Camera set: {cam.name}"
        else:
            cam_name = sc.camera.name if sc.camera else ""
            msg_cam = f"No camera suffixed _{self.preset}; kept current."

        # Force format (if enabled)
        forced_fmt = None
        if sc.qac_force_format:
            sc.render.image_settings.file_format = sc.qac_forced_format
            forced_fmt = sc.qac_forced_format

        # Auto output path
        if sc.qac_auto_output:
            ok, msg = _set_output_path(
                sc,
                self.preset,
                cam_name,
                sc.qac_overwrite_policy,
                sc.qac_root_folder,
                sc.qac_filename_template,
                forced_fmt,
            )
            self.report({'INFO'}, msg)
        else:
            self.report({'INFO'}, msg_cam)

        return {'FINISHED'}

# -------------------------------
# Panel (unified N-panel: m Tools)
# -------------------------------
class QAC_PT_panel(bpy.types.Panel):
    bl_idname = 'QAC_PT_panel'
    bl_parent_id = 'MTB_PT_root'
    bl_category = 'm Tools'
    bl_region_type = 'UI'
    bl_space_type = 'VIEW_3D'
    bl_label = "Quick Aspect + Camera"

    def draw(self, context):
        sc = context.scene
        col = self.layout.column(align=True)

        # Static prerequisites note
        note = "Prereq: Name cameras with suffix (_1080x1080, _1920x1080, _1080x1920, _1080x1350, _1200x1200) or tag via 'Tag Active Camera'. Preset click sets resolution and selects that camera."
        col.label(text=note)

        col.separator()
        col.label(text="Presets:")
        row = col.row(align=True)
        row.operator("qac.apply_preset", text="1080×1080").preset = "1080x1080"
        row.operator("qac.apply_preset", text="1920×1080").preset = "1920x1080"
        row = col.row(align=True)
        row.operator("qac.apply_preset", text="1080×1920").preset = "1080x1920"
        row.operator("qac.apply_preset", text="1080×1350").preset = "1080x1350"
        row.operator("qac.apply_preset", text="1200×1200").preset = "1200x1200"

        col.separator()
        # Force format
        box_fmt = col.box()
        row = box_fmt.row(align=True)
        row.prop(sc, "qac_force_format", text="Force Format")
        row.prop(sc, "qac_forced_format", text="")
        # Auto output path
        box = col.box()
        box.prop(sc, "qac_auto_output", text="Auto Output Path")
        if sc.qac_auto_output:
            box.prop(sc, "qac_root_folder", text="Root Folder")
            box.prop(sc, "qac_filename_template", text="Filename Template")
            box.prop(sc, "qac_overwrite_policy", text="Overwrite Policy")

        col.separator()
        col.label(text="Setup helpers:")
        col.operator("qac.tag_active_camera", icon="OUTLINER_DATA_CAMERA")
        col.operator("qac.duplicate_for_other_preset", icon="DUPLICATE")

# -------------------------------
# Register
# -------------------------------
classes = (
    QAC_OT_conflict_dialog,
    QAC_OT_tag_active_camera,
    QAC_OT_duplicate_for_other_preset,
    QAC_OT_apply_preset,
    QAC_PT_panel,
)

def register():
    # Register the shim root first if we created it
    if _QAC_SHIM_ROOT:
        try:
            bpy.utils.register_class(MTB_PT_root)
        except Exception:
            pass

    # Register panel + operators
    for c in classes:
        bpy.utils.register_class(c)

    # Scene properties (stored in .blend)
    bpy.types.Scene.qac_auto_output = BoolProperty(
        name="Auto Output Path",
        default=True,
        description="When applying a preset, auto-build render.filepath to the chosen root/folder",
    )
    bpy.types.Scene.qac_root_folder = StringProperty(
        name="Root Folder",
        default="//../Renders/",
        description="Base folder for renders (use // for relative to the .blend). Example: //../Renders/",
        subtype='DIR_PATH',
    )
    bpy.types.Scene.qac_filename_template = StringProperty(
        name="Filename Template",
        default="{blendname}_{preset}_",   # trailing underscore so frames become ..._0001.png
        description="Tokens: {blendname}, {scene}, {camera}, {preset}, {date}, {time}",
    )
    bpy.types.Scene.qac_overwrite_policy = EnumProperty(
        name="Overwrite Policy",
        items=(
            ('PROMPT', "Prompt", "Ask what to do if a file already exists (shows dialog)"),
            ('AUTO_SUFFIX', "Auto-suffix", "Append/increment _vNN automatically"),
            ('CANCEL', "Cancel", "Do nothing if a conflict is detected"),
            ('OVERWRITE_ONCE', "Overwrite (this time)", "Proceed and overwrite this time only"),
        ),
        default='PROMPT',
    )
    # Format forcing
    bpy.types.Scene.qac_force_format = BoolProperty(
        name="Force Format",
        default=False,
        description="When enabled, the preset sets the image file format before building output path",
    )
    bpy.types.Scene.qac_forced_format = EnumProperty(
        name="Format",
        items=IMAGE_FORMATS,
        default='PNG',
        description="Image file format to force when applying a preset",
    )
    # Temp holders for conflict dialog
    bpy.types.Scene.qac_conflict_dir = StringProperty(default="")
    bpy.types.Scene.qac_conflict_base = StringProperty(default="")
    bpy.types.Scene.qac_conflict_anim = StringProperty(default="0")

def unregister():
    # Remove properties
    for attr in (
        "qac_auto_output",
        "qac_root_folder",
        "qac_filename_template",
        "qac_overwrite_policy",
        "qac_force_format",
        "qac_forced_format",
        "qac_conflict_dir",
        "qac_conflict_base",
        "qac_conflict_anim",
    ):
        try:
            delattr(bpy.types.Scene, attr)
        except Exception:
            pass

    # Unregister panel + operators
    for c in reversed(classes):
        try:
            bpy.utils.unregister_class(c)
        except Exception:
            pass

    # Unregister shim root last if we added it
    if _QAC_SHIM_ROOT:
        try:
            bpy.utils.unregister_class(MTB_PT_root)
        except Exception:
            pass

