bl_info = {
    "name": "Camera From View + Lock",
    "blender": (5, 0, 0),
    "category": "3D View",
    "author": "Manojit",
    "description": "Create a camera from the current view, lock it, auto-name, and put it in a Cameras collection",
}

import bpy
from mathutils import Matrix

def get_next_camera_name():
    i = 1
    while True:
        name = f"Cam_{i:03d}"
        if name not in bpy.data.cameras:
            return name
        i += 1

def get_or_create_camera_collection():
    col_name = "Cameras"
    if col_name in bpy.data.collections:
        return bpy.data.collections[col_name]
    else:
        new_col = bpy.data.collections.new(col_name)
        bpy.context.scene.collection.children.link(new_col)
        return new_col

class VIEW3D_PT_camera_from_view_lock(bpy.types.Panel):
    # Fixed: removed duplicate attribute declarations; second set was overriding bl_category to 'View'
    bl_idname = 'VIEW3D_PT_camera_from_view_lock'
    bl_parent_id = 'MTB_PT_root'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'm Tools'
    bl_label = "Camera From View + Lock"

    def draw(self, context):
        layout = self.layout
        layout.operator("view3d.camera_from_view_lock", text="Create & Lock Camera")

class VIEW3D_OT_camera_from_view_lock(bpy.types.Operator):
    bl_idname = "view3d.camera_from_view_lock"
    bl_label = "Create Camera from View + Lock"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        area = None
        space = None

        for a in context.screen.areas:
            if a.type == 'VIEW_3D':
                area = a
                space = a.spaces.active
                break

        if not area or not space:
            self.report({'ERROR'}, "No 3D View found!")
            return {'CANCELLED'}

        view_matrix = space.region_3d.view_matrix.inverted()

        cam_name = get_next_camera_name()
        cam_data = bpy.data.cameras.new(name=cam_name)

        cam_obj = bpy.data.objects.new(cam_name, cam_data)
        cam_obj.matrix_world = view_matrix

        cam_col = get_or_create_camera_collection()
        cam_col.objects.link(cam_obj)

        for col in bpy.data.collections:
            if col != cam_col and cam_obj.name in col.objects:
                col.objects.unlink(cam_obj)

        context.scene.camera = cam_obj
        bpy.context.view_layer.objects.active = cam_obj
        cam_obj.select_set(True)

        space.region_3d.view_perspective = 'CAMERA'
        space.lock_camera = True

        self.report({'INFO'}, f"Camera {cam_obj.name} created and locked!")
        return {'FINISHED'}

classes = [VIEW3D_PT_camera_from_view_lock, VIEW3D_OT_camera_from_view_lock]

def register():
    for cls in classes:
        bpy.utils.register_class(cls)

def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)

if __name__ == "__main__":
    register()
