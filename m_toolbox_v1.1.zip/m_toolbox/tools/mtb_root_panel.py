# tools/mtb_root_panel.py
TOOL_INFO = {"id":"mtb_root_panel","name":"m Toolbox (Root)","description":"Shared root panel for all m Toolbox tools."}
import bpy
class MTB_PT_root(bpy.types.Panel):
    bl_label = "m Toolbox"
    bl_idname = "MTB_PT_root"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'm Tools'
    def draw(self, context): pass
classes = (MTB_PT_root,)
def register(): 
    for c in classes: bpy.utils.register_class(c)
def unregister():
    for c in reversed(classes): bpy.utils.unregister_class(c)
